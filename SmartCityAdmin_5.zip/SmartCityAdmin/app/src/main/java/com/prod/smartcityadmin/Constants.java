package com.prod.smartcityadmin;

public class Constants {
    public static final String HERE_API_KEY = "MoQ0dUWNJV-bKC-CYHsacni-G80cCWiX31B4fRAuM-o";
    public static String USER_UUID = "";
}

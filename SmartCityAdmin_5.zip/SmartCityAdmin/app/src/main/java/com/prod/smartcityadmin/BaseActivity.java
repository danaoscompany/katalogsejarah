package com.prod.smartcityadmin;

import android.app.ProgressDialog;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.appcompat.app.AppCompatActivity;

public class BaseActivity extends AppCompatActivity {

    public void show(String message) {
        Util.show(this, message);
    }

    public void show(int message) {
        Util.show(this, message);
    }

    public void log(String message) {
        Util.log(message);
    }

    public String read(String name, String value) {
        return Util.read(this, name, value);
    }

    public void write(String name, String value) {
        Util.write(this, name, value);
    }

    public ProgressDialog createDialog(String str) {
        return Util.createDialog(this, str);
    }

    public ProgressDialog createDialog(int i) {
        return Util.createDialog(this, i);
    }

    public interface PermissionListener {

        void onPermissionGranted();
        void onPermissionDenied();
    }

    private PermissionListener listener = null;

    public void checkPermissions(String[] permissions, PermissionListener listener) {
        this.listener = listener;
        if (Build.VERSION.SDK_INT >= 23) {
            boolean granted = true;
            for (String permission:permissions) {
                if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
                    granted = false;
                    break;
                }
            }
            if (granted) {
                if (listener != null) {
                    listener.onPermissionGranted();
                }
            } else {
                requestPermissions(permissions, 1);
            }
        } else {
            if (listener != null) {
                listener.onPermissionGranted();
            }
        }
    }

    public interface LocationUpdateListener {

        void onLocationUpdate(double lat, double lng);
    }

    public void getLocation(final LocationUpdateListener listener) {
        Util.getLocation(this, new Util.LocationUpdateListener() {

            @Override
            public void onLocationUpdate(double lat, double lng) {
                if (listener != null) {
                    listener.onLocationUpdate(lat, lng);
                }
            }
        });
    }
}

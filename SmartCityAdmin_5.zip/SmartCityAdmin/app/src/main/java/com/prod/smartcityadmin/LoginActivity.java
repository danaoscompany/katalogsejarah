package com.prod.smartcityadmin;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class LoginActivity extends BaseActivity {
    EditText emailField;
    EditText passwordField;
    ImageView viewPasswordImg;
    boolean passwordShown = false;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setTitle("");
        setContentView((int) R.layout.activity_login);
        emailField = findViewById(R.id.email);
        passwordField = findViewById(R.id.password);
        viewPasswordImg = findViewById(R.id.view_password_img);
        passwordField.setTransformationMethod(new PasswordTransformationMethod());
    }

    public void viewPassword(View view) {
        passwordShown = !passwordShown;
        if (passwordShown) {
            viewPasswordImg.setImageResource(R.drawable.hide_password);
            passwordField.setTransformationMethod(null);
        } else {
            viewPasswordImg.setImageResource(R.drawable.view_password);
            passwordField.setTransformationMethod(new PasswordTransformationMethod());
        }
    }

    public void login(View view) {
        final String email = this.emailField.getText().toString().trim();
        final String password = this.passwordField.getText().toString();
        if (email.equals("")) {
            show(R.string.text5);
            return;
        }
        if (password.equals("")) {
            show(R.string.text6);
            return;
        }
        final ProgressDialog dialog = createDialog(R.string.logging_in);
        dialog.show();
        FirebaseDatabase.getInstance().getReference("admins").orderByChild("email").equalTo(email)
                .addListenerForSingleValueEvent(new ValueEventListener() {

                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot snapshot:dataSnapshot.getChildren()) {
                            String uuid = snapshot.getKey();
                            String name = "";
                            String storedPassword = "";
                            for (DataSnapshot snapshot2:snapshot.getChildren()) {
                                if (snapshot2.getKey().equals("name")) {
                                    name = snapshot2.getValue(String.class);
                                } else if (snapshot2.getKey().equals("password")) {
                                    storedPassword = snapshot2.getValue(String.class);
                                }
                            }
                            dialog.dismiss();
                            if (password.equals(storedPassword)) {
                                Constants.USER_UUID = uuid;
                                write("email", email);
                                write("password", password);
                                startActivity(new Intent(LoginActivity.this, HomeActivity.class));
                                finish();
                            } else {
                                show(R.string.text7);
                            }
                            return;
                        }
                        show(R.string.text8);
                        dialog.dismiss();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
    }
}
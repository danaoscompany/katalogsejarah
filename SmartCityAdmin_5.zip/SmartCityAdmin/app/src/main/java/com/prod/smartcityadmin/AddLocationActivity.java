package com.prod.smartcityadmin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;

import com.firebase.geofire.GeoFire;
import com.firebase.geofire.GeoLocation;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.UUID;

public class AddLocationActivity extends BaseActivity {
    EditText nameField;
    GoogleMap map;
    double latitude = 0;
    double longitude = 0;
    String category = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_location);
        setTitle("Tambah Lokasi");
        setSupportActionBar((Toolbar)findViewById(R.id.toolbar));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        nameField = findViewById(R.id.name);
        category = getIntent().getStringExtra("category");
        SupportMapFragment mf = (SupportMapFragment)getSupportFragmentManager().findFragmentById(R.id.mf);
        mf.getMapAsync(new OnMapReadyCallback() {

            @Override
            public void onMapReady(GoogleMap googleMap) {
                map = googleMap;
                getLocation(new LocationUpdateListener() {

                    @Override
                    public void onLocationUpdate(double lat, double lng) {
                        map.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(lat, lng), 15.0f));

                    }
                });
                map.setOnMapClickListener(new GoogleMap.OnMapClickListener() {

                    @Override
                    public void onMapClick(LatLng latLng) {
                        map.clear();
                        latitude = latLng.latitude;
                        longitude = latLng.longitude;
                        BitmapDescriptor icon = BitmapDescriptorFactory.defaultMarker();
                        if (category.equals("hotel")) {
                            icon = BitmapDescriptorFactory.fromResource(R.drawable.hotel_marker);
                        } else if (category.equals("bank")) {
                            icon = BitmapDescriptorFactory.fromResource(R.drawable.bank_marker);
                        } else if (category.equals("atm")) {
                            icon = BitmapDescriptorFactory.fromResource(R.drawable.atm_marker);
                        } else if (category.equals("restaurant")) {
                            icon = BitmapDescriptorFactory.fromResource(R.drawable.restaurant_marker);
                        } else if (category.equals("gas_station")) {
                            icon = BitmapDescriptorFactory.fromResource(R.drawable.gas_station_marker);
                        } else if (category.equals("hospital")) {
                            icon = BitmapDescriptorFactory.fromResource(R.drawable.hospital_marker);
                        } else if (category.equals("school")) {
                            icon = BitmapDescriptorFactory.fromResource(R.drawable.school_marker);
                        } else if (category.equals("office")) {
                            icon = BitmapDescriptorFactory.fromResource(R.drawable.office_marker);
                        } else if (category.equals("worship_place")) {
                            icon = BitmapDescriptorFactory.fromResource(R.drawable.worship_place_marker);
                        }
                        map.addMarker(new MarkerOptions().position(latLng).icon(icon));
                        map.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15.0f));
                    }
                });
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.add_location, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            finish();
        } else if (id == R.id.save) {
            final String name = nameField.getText().toString().trim();
            if (name.equals("")) {
                Util.show(this, "Mohon masukkan nama");
                return false;
            }
            final ProgressDialog dialog = Util.createDialog(this, "Menyimpan...");
            dialog.show();
            String uuid = UUID.randomUUID().toString();
            GeoFire geoFire = new GeoFire(FirebaseDatabase.getInstance().getReference("locations"));
            geoFire.setLocation(uuid, new GeoLocation(latitude, longitude), new GeoFire.CompletionListener() {

                @Override
                public void onComplete(String key, DatabaseError error) {
                    if (error == null) {
                        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("locations").child(uuid);
                        ref.child("name").setValue(name).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                ref.child("category").setValue(category).addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        ref.child("latitude").setValue(latitude).addOnSuccessListener(new OnSuccessListener<Void>() {
                                            @Override
                                            public void onSuccess(Void aVoid) {
                                                ref.child("longitude").setValue(longitude).addOnSuccessListener(new OnSuccessListener<Void>() {
                                                    @Override
                                                    public void onSuccess(Void aVoid) {
                                                        dialog.dismiss();
                                                        setResult(Activity.RESULT_OK);
                                                        finish();
                                                    }
                                                });
                                            }
                                        });
                                    }
                                });
                            }
                        });
                    } else {
                        dialog.dismiss();
                        show("Kesalahan dalam menyimpan lokasi: "+error.getMessage());
                    }
                }
            });
        }
        return false;
    }
}
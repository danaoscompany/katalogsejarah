package com.prod.smartcityadmin.adapter;

import android.content.Context;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.prod.smartcityadmin.R;
import com.prod.smartcityadmin.Util;

import org.json.JSONObject;

import java.util.ArrayList;

public class LocationAdapter extends RecyclerView.Adapter<LocationAdapter.ViewHolder> {
    Context context;
    ArrayList<JSONObject> locations;
    Listener listener;

    public LocationAdapter(Context ctx, ArrayList<JSONObject> locations, Listener listener) {
        this.context = ctx;
        this.locations = locations;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.location, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        try {
            final JSONObject location = locations.get(position);
            holder.name.setText(Html.fromHtml("<b>Nama:</b> "+Util.getString(location, "name", "").trim()));
            holder.latitude.setText(Html.fromHtml("<b>Latitude:</b> "+Util.getDouble(location, "latitude", 0)));
            holder.longitude.setText(Html.fromHtml("<b>Longitude:</b> "+Util.getDouble(location, "longitude", 0)));
            holder.select.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        listener.onLocationSelected(position, location);
                    }
                }
            });
            holder.check.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        listener.onLocationChecked(position, location);
                    }
                }
            });
            holder.edit.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        listener.onLocationEdited(position, location);
                    }
                }
            });
            holder.delete.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        listener.onLocationDeleted(position, location);
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return locations.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public LinearLayout select;
        public TextView name, latitude, longitude;
        public Button check, edit, delete;

        public ViewHolder(View view) {
            super(view);
            select = view.findViewById(R.id.select);
            name = view.findViewById(R.id.name);
            latitude = view.findViewById(R.id.latitude);
            longitude = view.findViewById(R.id.longitude);
            check = view.findViewById(R.id.check);
            edit = view.findViewById(R.id.edit);
            delete = view.findViewById(R.id.delete);
        }
    }

    public interface Listener {

        void onLocationSelected(int position, JSONObject location);
        void onLocationChecked(int position, JSONObject location);
        void onLocationEdited(int position, JSONObject location);
        void onLocationDeleted(int position, JSONObject location);
    }
}

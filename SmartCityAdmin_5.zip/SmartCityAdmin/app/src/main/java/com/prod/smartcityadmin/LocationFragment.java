package com.prod.smartcityadmin;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.firebase.geofire.GeoFire;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.prod.smartcityadmin.adapter.LocationAdapter;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Locale;

public class LocationFragment extends Fragment {
    private final int ADD_LOCATION = 1;
    private final int EDIT_LOCATION = 2;
    View view;
    HomeActivity activity;
    RecyclerView locationList;
    ArrayList<JSONObject> locations;
    LocationAdapter adapter;
    String category;
    RelativeLayout progress;
    SwipeRefreshLayout swipe;
    FloatingActionButton add;

    public LocationFragment(String category) {
        this.category = category;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_location, container, false);
        locationList = view.findViewById(R.id.locations);
        progress = view.findViewById(R.id.progress);
        swipe = view.findViewById(R.id.swipe);
        add = view.findViewById(R.id.add);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        activity = (HomeActivity)getActivity();
        locationList.setLayoutManager(new LinearLayoutManager(activity));
        locationList.setItemAnimator(new DefaultItemAnimator());
        locations = new ArrayList<>();
        adapter = new LocationAdapter(activity, locations, new LocationAdapter.Listener() {

            @Override
            public void onLocationSelected(int position, JSONObject location) {
            }

            @Override
            public void onLocationChecked(int position, JSONObject location) {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(String.format(Locale.ENGLISH, "geo:%f,%f",
                        Util.getDouble(location, "latitude", 0),
                        Util.getDouble(location, "longitude", 0))));
                startActivity(i);
            }

            @Override
            public void onLocationEdited(int position, JSONObject location) {
                Intent i = new Intent(activity, EditLocationActivity.class);
                i.putExtra("uuid", Util.getString(location, "uuid", "").trim());
                i.putExtra("category", category);
                i.putExtra("name", Util.getString(location, "name", "").trim());
                i.putExtra("latitude", Util.getDouble(location, "latitude", 0));
                i.putExtra("longitude", Util.getDouble(location, "longitude", 0));
                startActivityForResult(i, EDIT_LOCATION);
            }

            @Override
            public void onLocationDeleted(int position, JSONObject location) {
                new AlertDialog.Builder(activity)
                        .setMessage("Apakah Anda yakin ingin menghapus lokasi berikut?")
                        .setPositiveButton("Ya", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialogInterface, int which) {
                                final ProgressDialog dialog = activity.createDialog("Menghapus lokasi...");
                                dialog.show();
                                FirebaseDatabase.getInstance().getReference("locations")
                                        .child(Util.getString(location, "uuid", ""))
                                        .removeValue()
                                        .addOnSuccessListener(new OnSuccessListener<Void>() {

                                            @Override
                                            public void onSuccess(Void aVoid) {
                                                GeoFire geoFire = new GeoFire(FirebaseDatabase.getInstance().getReference("locations"));
                                                geoFire.removeLocation(Util.getString(location, "uuid", "").trim());
                                                dialog.dismiss();
                                                getLocations();
                                            }
                                        });
                            }
                        })
                        .setNegativeButton("Tidak", null)
                        .create()
                        .show();
            }
        });
        locationList.setAdapter(adapter);
        getLocations();
        swipe.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {

            @Override
            public void onRefresh() {
                getLocations();
            }
        });
        add.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(activity, AddLocationActivity.class)
                        .putExtra("category", category), ADD_LOCATION);
            }
        });
    }

    public void getLocations() {
        progress.setVisibility(View.VISIBLE);
        locations.clear();
        adapter.notifyDataSetChanged();
        FirebaseDatabase.getInstance().getReference("locations").orderByChild("category").equalTo(category)
                .addListenerForSingleValueEvent(new ValueEventListener() {

                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                            String uuid = snapshot.getKey();
                            String name = "";
                            double latitude = 0;
                            double longitude = 0;
                            for (DataSnapshot snapshot2 : snapshot.getChildren()) {
                                if (snapshot2.getKey().equals("name")) {
                                    name = snapshot2.getValue(String.class);
                                } else if (snapshot2.getKey().equals("latitude")) {
                                    latitude = snapshot2.getValue(Double.class);
                                } else if (snapshot2.getKey().equals("longitude")) {
                                    longitude = snapshot2.getValue(Double.class);
                                }
                            }
                            try {
                                JSONObject location = new JSONObject();
                                location.put("uuid", uuid);
                                location.put("name", name);
                                location.put("latitude", latitude);
                                location.put("longitude", longitude);
                                locations.add(location);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        adapter.notifyDataSetChanged();
                        progress.setVisibility(View.GONE);
                        swipe.setRefreshing(false);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == ADD_LOCATION) {
                getLocations();
            } else if (requestCode == EDIT_LOCATION) {
                getLocations();
            }
        }
    }
}

package com.dn.katalogsejarah;

import android.os.Build;
import android.util.Log;

import org.json.JSONObject;

public class Util {

    public static void log(String message) {
        Log.e(Build.MODEL, message);
    }

    public static String getString(JSONObject obj, String name, String defaultValue) {
        try {
            String string = obj.getString(name);
            return (string == null || string.equals("null") || string.equals("NULL")) ? defaultValue : string;
        } catch (Exception e) {
            e.printStackTrace();
            return defaultValue;
        }
    }

    public static boolean getBoolean(JSONObject obj, String name, boolean defaultValue) {
        try {
            boolean value = obj.getBoolean(name);
            return value;
        } catch (Exception e) {
            e.printStackTrace();
            return defaultValue;
        }
    }
}

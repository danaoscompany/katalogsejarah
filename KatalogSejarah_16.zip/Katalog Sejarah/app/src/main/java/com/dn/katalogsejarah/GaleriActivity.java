package com.dn.katalogsejarah;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;

import com.dn.katalogsejarah.adapter.GaleriAdapter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONObject;

import java.util.ArrayList;

public class GaleriActivity extends BaseActivity {
    RecyclerView galleryList;
    ArrayList<JSONObject> galleries;
    GaleriAdapter adapter;
    ProgressBar progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_galeri);
        setTitle(R.string.gallery);
        setSupportActionBar((Toolbar)findViewById(R.id.toolbar));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        galleryList = findViewById(R.id.gallery);
        progress = findViewById(R.id.progress);
        galleryList.setLayoutManager(new GridLayoutManager(this, 2));
        galleryList.setItemAnimator(new DefaultItemAnimator());
        galleries = new ArrayList<>();
        adapter = new GaleriAdapter(this, galleries);
        galleryList.setAdapter(adapter);
        FirebaseDatabase.getInstance().getReference("galeri").orderByChild("name").equalTo("kerajaan_siak")
                .addListenerForSingleValueEvent(new ValueEventListener() {

                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot snapshot:dataSnapshot.getChildren()) {
                            String uuid = snapshot.getKey();
                            String name = "";
                            for (DataSnapshot snapshot2:snapshot.getChildren()) {
                                if (snapshot2.getKey().equals("name")) {
                                    name = snapshot2.getValue(String.class);
                                }
                            }
                            if (name.equals("kerajaan_siak")) {
                                for (DataSnapshot snapshot2:snapshot.getChildren()) {
                                    if (!snapshot2.getKey().equals("name")) {
                                        String image = "";
                                        String content = "";
                                        for (DataSnapshot snapshot3:snapshot2.getChildren()) {
                                            if (snapshot3.getKey().equals("image")) {
                                                image = snapshot3.getValue(String.class);
                                            } else if (snapshot3.getKey().equals("content")) {
                                                content = snapshot3.getValue(String.class);
                                            }
                                        }
                                        try {
                                            JSONObject gallery = new JSONObject();
                                            gallery.put("content", content);
                                            gallery.put("image", image);
                                            galleries.add(gallery);
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    }
                                }
                            }
                        }
                        progress.setVisibility(View.GONE);
                        adapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            finish();
        }
        return false;
    }
}
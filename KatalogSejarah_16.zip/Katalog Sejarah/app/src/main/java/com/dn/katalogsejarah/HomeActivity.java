package com.dn.katalogsejarah;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.IBinder;
import android.view.MenuItem;
import android.view.View;

import com.google.firebase.database.FirebaseDatabase;

public class HomeActivity extends BaseActivity {
    boolean bound = false;
    BackgroundService service;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        setTitle("");
        setSupportActionBar((Toolbar)findViewById(R.id.toolbar));
    }

    public void openMenu1(View view) {
        startActivity(new Intent(this, SejarahActivity.class));
    }

    public void openMenu2(View view) {
        startActivity(new Intent(this, PeninggalanActivity.class));
    }

    public void openMenu3(View view) {
        startActivity(new Intent(this, GaleriActivity.class));
    }

    public void openMenu4(View view) {
        startActivity(new Intent(this, VideoActivity.class));
    }

    public void openMenu5(View view) {
        startActivity(new Intent(this, QuizActivity.class));
    }

    public void openMenu6(View view) {
        startActivity(new Intent(this, MapActivity.class));
    }

    public void openMenu7(View view) {
        startActivity(new Intent(this, TentangActivity.class));
    }

    public void exit(View view) {
        try {
            if (bound) {
                service.mp.stop();
                service.mp.release();
                stopService(new Intent(this, BackgroundService.class));
                BackgroundService.started = false;
                bound = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        finish();
    }

    @Override
    protected void onStart() {
        super.onStart();
        Intent i = new Intent(this, BackgroundService.class);
        if (!BackgroundService.started) {
            startService(i);
        }
        bindService(i, sc, BIND_AUTO_CREATE);
    }

    private ServiceConnection sc = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            service = ((BackgroundService.BackgroundServiceBinder)binder).getService();
            bound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
        }
    };

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        return false;
    }

    @Override
    public void onBackPressed() {
        try {
            if (bound) {
                service.mp.stop();
                service.mp.release();
                stopService(new Intent(this, BackgroundService.class));
                BackgroundService.started = false;
                bound = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        finish();
    }
}
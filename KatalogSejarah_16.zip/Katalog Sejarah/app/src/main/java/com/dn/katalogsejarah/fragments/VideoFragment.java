package com.dn.katalogsejarah.fragments;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.dn.katalogsejarah.CustomVideoView;
import com.dn.katalogsejarah.PlayVideoActivity;
import com.dn.katalogsejarah.R;
import com.dn.katalogsejarah.VideoActivity;
import com.squareup.picasso.Picasso;

public class VideoFragment extends Fragment {
    View view;
    VideoActivity activity;
    RelativeLayout screenshotContainer;
    ImageView screenshotView;
    RelativeLayout videoContainer;
    public CustomVideoView videoView;
    TextView contentView;
    String screenshot = "";
    String content = "";
    String videoURI = "";

    public VideoFragment(String screenshot, String content, String videoURI) {
        this.screenshot = screenshot;
        this.content = content;
        this.videoURI = videoURI;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.video, container, false);
        screenshotContainer = view.findViewById(R.id.screenshot_container);
        screenshotView = view.findViewById(R.id.screenshot);
        videoContainer = view.findViewById(R.id.video_container);
        videoView = view.findViewById(R.id.video);
        contentView = view.findViewById(R.id.content);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        activity = (VideoActivity)getActivity();
        Picasso.get().load(Uri.parse(screenshot)).resize(512, 0).onlyScaleDown().into(screenshotView);
        contentView.setText(content);
        screenshotView.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                try {
                    if (activity.service != null) {
                        if (activity.service.mp.isPlaying()) {
                            activity.service.mp.pause();
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                startActivityForResult(new Intent(activity, PlayVideoActivity.class)
                        .putExtra("video_uri", videoURI), 1);
                /*screenshotContainer.setVisibility(View.GONE);
                videoContainer.setVisibility(View.VISIBLE);
                videoView.setVideoURI(Uri.parse(videoURI));
                videoView.setMediaController(new MediaController(activity));
                videoView.setListener(new CustomVideoView.Listener() {

                    @Override
                    public void onVideoStarted() {
                        try {
                            if (activity.service != null) {
                                if (activity.service.mp.isPlaying()) {
                                    activity.service.mp.pause();
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onVideoPaused() {
                        try {
                            if (activity.service != null) {
                                if (!activity.service.mp.isPlaying()) {
                                    activity.service.mp.start();
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
                videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {

                    @Override
                    public void onPrepared(MediaPlayer mp) {
                        try {
                            if (activity.service != null) {
                                activity.service.mp.pause();
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        videoView.start();
                    }
                });*/
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            if (activity.service != null) {
                if (!activity.service.mp.isPlaying()) {
                    activity.service.mp.start();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

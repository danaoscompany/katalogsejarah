package com.dn.katalogsejarah;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.VideoView;

public class CustomVideoView extends VideoView {
    Listener listener;

    public CustomVideoView(Context context) {
        super(context);
    }

    public CustomVideoView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CustomVideoView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    @Override
    public void pause() {
        super.pause();
        if (listener != null) {
            listener.onVideoPaused();
        }
    }

    @Override
    public void start() {
        super.start();
        if (listener != null) {
            listener.onVideoStarted();
        }
    }

    public interface Listener {

        void onVideoStarted();
        void onVideoPaused();
    }
}

package com.dn.katalogsejarah;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;

import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class ViewGalleryActivity extends BaseActivity {
    ImageView imgView;
    TextView contentView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_gallery);
        setTitle(R.string.view_gallery);
        setSupportActionBar((Toolbar)findViewById(R.id.toolbar));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        imgView = findViewById(R.id.img);
        contentView = findViewById(R.id.content);
        String imageURL = getIntent().getStringExtra("image");
        Picasso.get().load(Uri.parse(imageURL)).resize(2048, 0).onlyScaleDown().into(imgView);
        contentView.setText(getIntent().getStringExtra("content"));
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            finish();
        }
        return false;
    }
}
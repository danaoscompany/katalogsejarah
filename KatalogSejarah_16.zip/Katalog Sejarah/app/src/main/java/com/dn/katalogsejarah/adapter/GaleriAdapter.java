package com.dn.katalogsejarah.adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.dn.katalogsejarah.R;
import com.dn.katalogsejarah.Util;
import com.dn.katalogsejarah.ViewGalleryActivity;
import com.squareup.picasso.Picasso;

import org.json.JSONObject;

import java.util.ArrayList;

public class GaleriAdapter extends RecyclerView.Adapter<GaleriAdapter.ViewHolder> {
    Context context;
    ArrayList<JSONObject> galleries;

    public GaleriAdapter(Context ctx, ArrayList<JSONObject> galleries) {
        this.context = ctx;
        this.galleries = galleries;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.galeri, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        try {
            final JSONObject gallery = galleries.get(position);
            Picasso.get().load(Uri.parse(Util.getString(gallery, "image", "").trim()))
                    .resize(512, 0).onlyScaleDown().into(holder.imgView);
            holder.select.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    context.startActivity(new Intent(context, ViewGalleryActivity.class)
                            .putExtra("image", Util.getString(gallery, "image", "").trim())
                            .putExtra("content", Util.getString(gallery, "content", "").trim()));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return galleries.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public RelativeLayout select;
        public ImageView imgView;

        public ViewHolder(View view) {
            super(view);
            select = view.findViewById(R.id.select);
            imgView = view.findViewById(R.id.img);
        }
    }
}

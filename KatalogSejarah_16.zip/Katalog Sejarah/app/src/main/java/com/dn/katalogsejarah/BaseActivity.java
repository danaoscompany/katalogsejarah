package com.dn.katalogsejarah;

import androidx.appcompat.app.AppCompatActivity;

public class BaseActivity extends AppCompatActivity {

    public void log(String message) {
        Util.log(message);
    }
}

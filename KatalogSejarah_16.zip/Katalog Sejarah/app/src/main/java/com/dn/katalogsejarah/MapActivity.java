package com.dn.katalogsejarah;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MapActivity extends BaseActivity {
    GoogleMap map;
    ProgressBar progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        setTitle(R.string.map);
        setSupportActionBar((Toolbar)findViewById(R.id.toolbar));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        progress = findViewById(R.id.progress);
        SupportMapFragment mf = (SupportMapFragment)getSupportFragmentManager().findFragmentById(R.id.map);
        mf.getMapAsync(new OnMapReadyCallback() {

            @Override
            public void onMapReady(GoogleMap googleMap) {
                map = googleMap;
                FirebaseDatabase.getInstance().getReference("lokasi").orderByChild("name").equalTo("kerajaan_siak")
                        .addListenerForSingleValueEvent(new ValueEventListener() {

                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                for (DataSnapshot snapshot:dataSnapshot.getChildren()) {
                                    String uuid = snapshot.getKey();
                                    String name = "";
                                    double lat = 0;
                                    double lng = 0;
                                    for (DataSnapshot snapshot2:snapshot.getChildren()) {
                                        if (snapshot2.getKey().equals("name")) {
                                            name = snapshot2.getValue(String.class);
                                        } else if (snapshot2.getKey().equals("lat")) {
                                            lat = snapshot2.getValue(Double.class);
                                        } else if (snapshot2.getKey().equals("lng")) {
                                            lng = snapshot2.getValue(Double.class);
                                        }
                                    }
                                    if (name.equals("kerajaan_siak")) {
                                        LatLng latLng = new LatLng(lat, lng);
                                        map.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15.0f));
                                        map.addMarker(new MarkerOptions().position(latLng).icon(BitmapDescriptorFactory.defaultMarker()));
                                        progress.setVisibility(View.GONE);
                                    }
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                            }
                        });
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            finish();
        }
        return false;
    }
}
package com.dn.katalogsejarah.fragments;

import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.dn.katalogsejarah.HomeActivity;
import com.dn.katalogsejarah.R;
import com.dn.katalogsejarah.SejarahActivity;
import com.squareup.picasso.Picasso;

public class SejarahFragment extends Fragment {
    View view;
    SejarahActivity activity;
    ImageView imgView;
    TextView contentView;
    String image = "";
    String content = "";

    public SejarahFragment(String image, String content) {
        this.image = image;
        this.content = content;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.sejarah, container, false);
        imgView = view.findViewById(R.id.img);
        contentView = view.findViewById(R.id.content);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        activity = (SejarahActivity)getActivity();
        Picasso.get().load(Uri.parse(image)).resize(512, 0).onlyScaleDown().into(imgView);
        contentView.setText(content);
    }
}

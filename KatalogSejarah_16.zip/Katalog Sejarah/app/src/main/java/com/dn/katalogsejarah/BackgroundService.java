package com.dn.katalogsejarah;

import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.IBinder;

import androidx.core.app.NotificationCompat;

public class BackgroundService extends Service {
    public static BackgroundService instance;
    public static boolean started = false;
    BackgroundServiceBinder binder = new BackgroundServiceBinder();
    public MediaPlayer mp;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        instance = this;
        if (started) {
            return START_STICKY;
        }
        started = true;
        try {
            mp = new MediaPlayer();
            AssetFileDescriptor afd = getAssets().openFd("audio.mp3");
            mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {

                @Override
                public void onCompletion(MediaPlayer mp) {
                    Util.log("Media player complete");
                }
            });
            mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {

                @Override
                public void onPrepared(MediaPlayer mediaPlayer) {
                    mp.start();
                }
            });
            mp.prepareAsync();
        } catch (Exception e) {
            e.printStackTrace();
        }
        /*NotificationManager mgr = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, getPackageName()+".NOTIFICATIONS");
        builder.setContentTitle("Katalog Sejarah sedang berjalan");
        builder.setContentText("Ketuk untuk membuka aplikasi");
        builder.setPriority(NotificationCompat.PRIORITY_HIGH);
        builder.setOngoing(true);
        builder.setSmallIcon(R.mipmap.ic_launcher);
        mgr.notify(1, builder.build());
        startForeground(1, builder.build());*/
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    public class BackgroundServiceBinder extends Binder {

        public BackgroundService getService() {
            return BackgroundService.this;
        }
    }
}
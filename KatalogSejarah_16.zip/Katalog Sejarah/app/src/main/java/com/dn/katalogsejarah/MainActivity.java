package com.dn.katalogsejarah;

import androidx.appcompat.app.AppCompatActivity;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

public class MainActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        init();
    }

    public void init() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(getPackageName()+".NOTIFICATIONS",
                    "Katalog Sejarah notifications", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Manage notifications for Katalog Sejarah");
            NotificationManager mgr = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            mgr.createNotificationChannel(channel);
        }
        startActivity(new Intent(this, HomeActivity.class));
        finish();
    }
}
package com.dn.katalogsejarah;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.dn.katalogsejarah.adapter.QuizAdapter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;

import at.grabner.circleprogress.CircleProgressView;

public class QuizActivity extends BaseActivity {
    RecyclerView quizList;
    ArrayList<JSONObject> quizes;
    QuizAdapter adapter;
    Button finish;
    ProgressBar progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);
        setTitle(R.string.quiz);
        setSupportActionBar((Toolbar)findViewById(R.id.toolbar));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        quizList = findViewById(R.id.quiz);
        finish = findViewById(R.id.finish);
        progress = findViewById(R.id.progress);
        quizList.setLayoutManager(new LinearLayoutManager(this));
        quizList.setItemAnimator(new DefaultItemAnimator());
        quizes = new ArrayList<>();
        adapter = new QuizAdapter(this, quizes);
        quizList.setAdapter(adapter);
        getQuizes();
    }

    public void getQuizes() {
        FirebaseDatabase.getInstance().getReference("quiz").orderByChild("name").equalTo("kerajaan_siak")
                .addListenerForSingleValueEvent(new ValueEventListener() {

                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot snapshot:dataSnapshot.getChildren()) {
                            String uuid = snapshot.getKey();
                            for (DataSnapshot snapshot2:snapshot.getChildren()) {
                                if (snapshot2.getKey().equals("questions")) {
                                    for (DataSnapshot snapshot3:snapshot2.getChildren()) {
                                        String questionUUID = snapshot3.getKey();
                                        String question = "";
                                        String answer1 = "";
                                        String answer2 = "";
                                        String answer3 = "";
                                        String answer4 = "";
                                        String correct = "";
                                        for (DataSnapshot snapshot4:snapshot3.getChildren()) {
                                            if (snapshot4.getKey().equals("question")) {
                                                question = snapshot4.getValue(String.class);
                                            } else if (snapshot4.getKey().equals("answers")) {
                                                for (DataSnapshot snapshot5:snapshot4.getChildren()) {
                                                    if (snapshot5.getKey().equals("answer_1")) {
                                                        answer1 = snapshot5.getValue(String.class);
                                                    } else if (snapshot5.getKey().equals("answer_2")) {
                                                        answer2 = snapshot5.getValue(String.class);
                                                    } else if (snapshot5.getKey().equals("answer_3")) {
                                                        answer3 = snapshot5.getValue(String.class);
                                                    } else if (snapshot5.getKey().equals("answer_4")) {
                                                        answer4 = snapshot5.getValue(String.class);
                                                    } else if (snapshot5.getKey().equals("correct")) {
                                                        correct = snapshot5.getValue(String.class);
                                                    }
                                                }
                                            }
                                        }
                                        try {
                                            JSONObject questionJSON = new JSONObject();
                                            questionJSON.put("question", question);
                                            questionJSON.put("answer_1", answer1);
                                            questionJSON.put("answer_2", answer2);
                                            questionJSON.put("answer_3", answer3);
                                            questionJSON.put("answer_4", answer4);
                                            questionJSON.put("answer_1_text_color", "#FFFFFF");
                                            questionJSON.put("answer_2_text_color", "#FFFFFF");
                                            questionJSON.put("answer_3_text_color", "#FFFFFF");
                                            questionJSON.put("answer_4_text_color", "#FFFFFF");
                                            questionJSON.put("answer_1_enabled", true);
                                            questionJSON.put("answer_2_enabled", true);
                                            questionJSON.put("answer_3_enabled", true);
                                            questionJSON.put("answer_4_enabled", true);
                                            questionJSON.put("correct", correct);
                                            quizes.add(questionJSON);
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    }
                                }
                            }
                        }
                        Collections.shuffle(quizes);
                        if (quizes.size() > 10) {
                            quizes = (ArrayList<JSONObject>)quizes.subList(0, 10);
                        }
                        progress.setVisibility(View.GONE);
                        adapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
    }

    public void finishQuiz(View view0) {
        boolean allQuizFinished = true;
        for (int i=0; i<quizes.size(); i++) {
            JSONObject quiz = quizes.get(i);
            String answer = Util.getString(quiz, "answer", "").trim();
            if (answer.equals("")) {
                allQuizFinished = false;
                break;
            }
        }
        if (!allQuizFinished) {
            new AlertDialog.Builder(this)
                    .setMessage(R.string.text1)
                    .setPositiveButton(R.string.ok, null)
                    .create()
                    .show();
            return;
        }
        finish.setVisibility(View.GONE);
        int tmpTotalCorrects = 0;
        for (int i=0; i<quizes.size(); i++) {
            JSONObject quiz = quizes.get(i);
            try {
                quiz.put("answer_1_enabled", false);
                quiz.put("answer_2_enabled", false);
                quiz.put("answer_3_enabled", false);
                quiz.put("answer_4_enabled", false);
                String answer = Util.getString(quiz, "answer", "").trim();
                String correct = Util.getString(quiz, "correct", "").trim();
                if (answer.equals(correct)) {
                    if (answer.equals("answer_1")) {
                        quiz.put("answer_1_text_color", "#2ecc71");
                    } else if (answer.equals("answer_2")) {
                        quiz.put("answer_2_text_color", "#2ecc71");
                    } else if (answer.equals("answer_3")) {
                        quiz.put("answer_3_text_color", "#2ecc71");
                    } else if (answer.equals("answer_4")) {
                        quiz.put("answer_4_text_color", "#2ecc71");
                    }
                    tmpTotalCorrects++;
                } else {
                    if (answer.equals("answer_1")) {
                        quiz.put("answer_1_text_color", "#e74c3c");
                    } else if (answer.equals("answer_2")) {
                        quiz.put("answer_2_text_color", "#e74c3c");
                    } else if (answer.equals("answer_3")) {
                        quiz.put("answer_3_text_color", "#e74c3c");
                    } else if (answer.equals("answer_4")) {
                        quiz.put("answer_4_text_color", "#e74c3c");
                    }
                    if (correct.equals("answer_1")) {
                        quiz.put("answer_1_text_color", "#2ecc71");
                    } else if (correct.equals("answer_2")) {
                        quiz.put("answer_2_text_color", "#2ecc71");
                    } else if (correct.equals("answer_3")) {
                        quiz.put("answer_3_text_color", "#2ecc71");
                    } else if (correct.equals("answer_4")) {
                        quiz.put("answer_4_text_color", "#2ecc71");
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        adapter.notifyDataSetChanged();
        final int totalCorrects = tmpTotalCorrects;
        View view = LayoutInflater.from(this).inflate(R.layout.score, null);
        CircleProgressView progressView = view.findViewById(R.id.progress);
        TextView totalQuestionsView = view.findViewById(R.id.total_questions);
        TextView totalCorrectsView = view.findViewById(R.id.total_corrects);
        TextView totalIncorrectsView = view.findViewById(R.id.total_incorrects);
        totalQuestionsView.setText(Html.fromHtml("<b>"+getResources().getString(R.string.text2)+"</b> "+quizes.size()));
        totalCorrectsView.setText(Html.fromHtml("<b>"+getResources().getString(R.string.text3)+"</b> "+totalCorrects));
        totalIncorrectsView.setText(Html.fromHtml("<b>"+getResources().getString(R.string.text4)+"</b> "+(quizes.size()-totalCorrects)));
        Button ok = view.findViewById(R.id.ok);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(view)
                .setCancelable(false)
                .create();
        dialog.setOnShowListener(new DialogInterface.OnShowListener() {

            @Override
            public void onShow(DialogInterface dialog) {
                progressView.setValueAnimated(totalCorrects*100/quizes.size());
            }
        });
        ok.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            finish();
        }
        return false;
    }
}
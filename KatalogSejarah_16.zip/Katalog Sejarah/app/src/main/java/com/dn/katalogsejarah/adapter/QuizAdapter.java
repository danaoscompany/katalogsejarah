package com.dn.katalogsejarah.adapter;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.dn.katalogsejarah.R;
import com.dn.katalogsejarah.Util;

import org.json.JSONObject;

import java.util.ArrayList;

public class QuizAdapter extends RecyclerView.Adapter<QuizAdapter.ViewHolder> {
    Context context;
    ArrayList<JSONObject> quizes;

    public QuizAdapter(Context ctx, ArrayList<JSONObject> quizes) {
        this.context = ctx;
        this.quizes = quizes;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.quiz, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        try {
            JSONObject quiz = quizes.get(position);
            holder.questionView.setText(Util.getString(quiz, "question", ""));
            holder.answer1View.setText(Util.getString(quiz, "answer_1", ""));
            holder.answer2View.setText(Util.getString(quiz, "answer_2", ""));
            holder.answer3View.setText(Util.getString(quiz, "answer_3", ""));
            holder.answer4View.setText(Util.getString(quiz, "answer_4", ""));
            holder.answer1View.setTextColor(Color.parseColor(Util.getString(quiz, "answer_1_text_color", "")));
            holder.answer2View.setTextColor(Color.parseColor(Util.getString(quiz, "answer_2_text_color", "")));
            holder.answer3View.setTextColor(Color.parseColor(Util.getString(quiz, "answer_3_text_color", "")));
            holder.answer4View.setTextColor(Color.parseColor(Util.getString(quiz, "answer_4_text_color", "")));
            if (Build.VERSION.SDK_INT >= 21) {
                holder.answer1View.setButtonTintList(ColorStateList.valueOf(Color.parseColor(Util.getString(quiz, "answer_1_text_color", ""))));
                holder.answer2View.setButtonTintList(ColorStateList.valueOf(Color.parseColor(Util.getString(quiz, "answer_2_text_color", ""))));
                holder.answer3View.setButtonTintList(ColorStateList.valueOf(Color.parseColor(Util.getString(quiz, "answer_3_text_color", ""))));
                holder.answer4View.setButtonTintList(ColorStateList.valueOf(Color.parseColor(Util.getString(quiz, "answer_4_text_color", ""))));
            }
            holder.answer1View.setEnabled(Util.getBoolean(quiz, "answer_1_enabled", false));
            holder.answer2View.setEnabled(Util.getBoolean(quiz, "answer_2_enabled", false));
            holder.answer3View.setEnabled(Util.getBoolean(quiz, "answer_3_enabled", false));
            holder.answer4View.setEnabled(Util.getBoolean(quiz, "answer_4_enabled", false));
            holder.answer1View.setOnCheckedChangeListener(null);
            holder.answer2View.setOnCheckedChangeListener(null);
            holder.answer3View.setOnCheckedChangeListener(null);
            holder.answer4View.setOnCheckedChangeListener(null);
            String answer = Util.getString(quiz, "answer", "").trim();
            if (answer.equals("answer_1")) {
                holder.answer1View.setChecked(true);
                holder.answer2View.setChecked(false);
                holder.answer3View.setChecked(false);
                holder.answer4View.setChecked(false);
            } else if (answer.equals("answer_2")) {
                holder.answer1View.setChecked(false);
                holder.answer2View.setChecked(true);
                holder.answer3View.setChecked(false);
                holder.answer4View.setChecked(false);
            } else if (answer.equals("answer_3")) {
                holder.answer1View.setChecked(false);
                holder.answer2View.setChecked(false);
                holder.answer3View.setChecked(true);
                holder.answer4View.setChecked(false);
            } else if (answer.equals("answer_4")) {
                holder.answer1View.setChecked(false);
                holder.answer2View.setChecked(false);
                holder.answer3View.setChecked(false);
                holder.answer4View.setChecked(true);
            }
            holder.answer1View.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked) {
                        try {
                            quiz.put("answer", "answer_1");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            });
            holder.answer2View.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked) {
                        try {
                            quiz.put("answer", "answer_2");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            });
            holder.answer3View.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked) {
                        try {
                            quiz.put("answer", "answer_3");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            });
            holder.answer4View.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked) {
                        try {
                            quiz.put("answer", "answer_4");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return quizes.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView questionView;
        public RadioButton answer1View, answer2View, answer3View, answer4View;

        public ViewHolder(View view) {
            super(view);
            questionView = view.findViewById(R.id.question);
            answer1View = view.findViewById(R.id.answer_1);
            answer2View = view.findViewById(R.id.answer_2);
            answer3View = view.findViewById(R.id.answer_3);
            answer4View = view.findViewById(R.id.answer_4);
        }
    }
}

package com.dn.katalogsejarah;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.dn.katalogsejarah.adapter.ViewPagerAdapter;
import com.dn.katalogsejarah.fragments.SejarahFragment;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

public class SejarahActivity extends BaseActivity {
    ImageView imgView;
    TextView contentView;
    ProgressBar progress;
    ViewPager vp;
    ViewPagerAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sejarah);
        setTitle(R.string.history);
        setSupportActionBar((Toolbar)findViewById(R.id.toolbar));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        imgView = findViewById(R.id.img);
        contentView = findViewById(R.id.content);
        progress = findViewById(R.id.progress);
        vp = findViewById(R.id.vp);
        adapter = new ViewPagerAdapter(getSupportFragmentManager());
        FirebaseDatabase.getInstance().getReference("sejarah").orderByChild("name").equalTo("kerajaan_siak")
                .addListenerForSingleValueEvent(new ValueEventListener() {

                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot snapshot:dataSnapshot.getChildren()) {
                            String uuid = snapshot.getKey();
                            String name = "";
                            for (DataSnapshot snapshot2:snapshot.getChildren()) {
                                if (snapshot2.getKey().equals("name")) {
                                    name = snapshot2.getValue(String.class);
                                }
                            }
                            if (name.equals("kerajaan_siak")) {
                                for (DataSnapshot snapshot2:snapshot.getChildren()) {
                                    if (!snapshot2.getKey().equals("name")) {
                                        String sejarahUUID = snapshot2.getKey();
                                        String image = "", content = "";
                                        for (DataSnapshot snapshot3 : snapshot2.getChildren()) {
                                            if (snapshot3.getKey().equals("image")) {
                                                image = snapshot3.getValue(String.class);
                                            } else if (snapshot3.getKey().equals("content")) {
                                                content = snapshot3.getValue(String.class);
                                            }
                                        }
                                        SejarahFragment fr = new SejarahFragment(image, content);
                                        adapter.add(fr, "");
                                    }
                                }
                            }
                        }
                        vp.setAdapter(adapter);
                        progress.setVisibility(View.GONE);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        log(error.getMessage());
                    }
                });
    }

    public void goToNextPage(View view) {
        if (vp.getCurrentItem() < vp.getAdapter().getCount()-1) {
            vp.setCurrentItem(vp.getCurrentItem()+1);
        }
    }

    public void goToPrevPage(View view) {
        if (vp.getCurrentItem() > 0) {
            vp.setCurrentItem(vp.getCurrentItem()-1);
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            finish();
        }
        return false;
    }
}
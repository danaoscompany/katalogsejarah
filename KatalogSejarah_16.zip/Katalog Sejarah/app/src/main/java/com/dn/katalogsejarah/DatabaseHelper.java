package com.dn.katalogsejarah;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "katalog_sejarah";
    private static final int DB_VERSION = 1;

    public DatabaseHelper(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table sejarah (_id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, image TEXT NOT NULL, content TEXT NOT NULL)");
        db.execSQL("create table peninggalan (_id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, image TEXT NOT NULL, content TEXT NOT NULL)");
        db.execSQL("create table galeri (_id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, image TEXT NOT NULL)");
        db.execSQL("insert into sejarah (name, image, content) values ('kerajaan_siak', 'https://upload.wikimedia.org/wikipedia/commons/a/a8/Istana_Kerajaan_Siak_%281%29.jpg', 'Kerajaan Siak Sri Indrapura didirikan pada tahun 1723 M oleh Raja Kecik yang bergelar Sultan Abdul Jalil Rahmat Syah putera Raja Johor (Sultan Mahmud Syah) dengan istrinya Encik Pong, dengan pusat kerajaan berada di Buantan. Konon nama Siak berasal dari nama sejenis tumbuh-tumbuhan yaitu siak-siak yang banyak terdapat di situ. Sebelum kerajaan Siak berdiri, daerah Siak berada dibawah kekuasaan Johor. Yang memerintah dan mengawasi daerah ini adalah raja yang ditunjuk dan diangkat oleh Sultan Johor. Namun hampir 100 tahun daerah ini tidak ada yang memerintah. Daerah ini diawasi oleh Syahbandar yang ditunjuk untuk memungut cukai hasil hutan dan hasil laut.\n" +
                "\n" +
                "Pada awal tahun 1699 Sultan Kerajaan Johor bergelar Sultan Mahmud Syah II mangkat dibunuh Magat Sri Rama, istrinya yang bernama Encik Pong pada waktu itu sedang hamil dilarikan ke Singapura, terus ke Jambi. Dalam perjalanan itu lahirlah Raja Kecik dan kemudian dibesarkan di Kerajaan Pagaruyung Minangkabau. Sementara itu pucuk pimpinan Kerajaan Johor diduduki oleh Datuk Bendahara tun Habib yang bergelar Sultan Abdul Jalil Riayat Syah.\n" +
                "\n" +
                "Setelah Raja Kecik dewasa, pada tahun 1717 Raja Kecik berhasil merebut tahta Johor. Tetapi tahun 1722 Kerajaan Johor tersebut direbut kembali oleh Tengku Sulaiman ipar Raja Kecik yang merupakan putera Sultan Abdul Jalil Riayat Syah. Dalam merebut Kerajaan Johor ini, Tengku Sulaiman dibantu oleh beberapa bangsawan Bugis. Terjadilah perang saudara yang mengakibatkan kerugian yang cukup besar pada kedua belah pihak, maka akhirnya masing-masing pihak mengundurkan diri. Pihak Johor mengundurkan diri ke Pahang, dan Raja Kecik mengundurkan diri ke Bintan dan seterusnya mendirikan negeri baru di pinggir Sungai Buantan (anak Sungai Siak). Demikianlah awal berdirinya kerajaan Siak di Buantan. Namun, pusat Kerajaan Siak tidak menetap di Buantan.\n" +
                "\n" +
                "Pusat kerajaan kemudian selalu berpindah-pindah dari kota Buantan pindah ke Mempura, pindah kemudian ke Senapelan Pekanbaru dan kembali lagi ke Mempura. Semasa pemerintahan Sultan Ismail dengan Sultan Assyaidis Syarif Ismail Jalil Jalaluddin (1827-1864) pusat Kerajaan Siak dipindahkan ke kota Siak Sri Indrapura dan akhirnya menetap disana sampai akhirnya masa pemerintahan Sultan Siak terakhir.\n" +
                "\n" +
                "Pada masa Sultan ke-11 yaitu Sultan Assayaidis Syarief Hasyim Abdul Jalil Syaifuddin yang memerintah pada tahun 1889-1908, dibangunlah istana yang megah terletak di kota Siak dan istana ini diberi nama Istana Asseraiyah Hasyimiah yang dibangun pada tahun 1889. Pada masa pemerintahan Sultan Syarif Hasyim ini Siak mengalami kemajuan terutama dibidang ekonomi. Dan masa itu pula beliau berkesempatan melawat ke Eropa yaitu Jerman dan Belanda.\n" +
                "\n" +
                "Setelah wafat, beliau digantikan oleh putranya yang masih kecil dan sedang bersekolah di Batavia yaitu Tengku Sulung Syarif Kasim dan baru pada tahun 1915 beliau ditabalkan sebagai Sultan Siak ke-12 dengan gelar Assayaidis Syarif Kasim Abdul Jalil Syaifuddin dan terakhir terkenal dengan nama Sultan Syarif Kasim Tsani (Sultan Syarif Kasim II). Bersamaan dengan diproklamirkannya Kemerdekaan Republik Indonesia, beliau pun mengibarkan bendera merah putih di Istana Siak dan tak lama kemudian beliau berangkat ke Jawa menemui Bung Karno dan menyatakan bergabung dengan Republik Indonesia sambil menyerahkan Mahkota Kerajaan serta uang sebesar Sepuluh Ribu Gulden. Dan sejak itu beliau meninggalkan Siak dan bermukim di Jakarta.Baru pada tahun 1960 kembali ke Siak dan mangkat di Rumbai pada tahun 1968.\n" +
                "\n" +
                "Beliau tidak meninggalkan keturunan baik dari Permaisuri Pertama Tengku Agung maupun dari Permaisuri Kedua Tengku Maharatu. Pada tahun 1997 Sultan Syarif Kasim II mendapat gelar Kehormatan Kepahlawanan sebagai seorang Pahlawan Nasional Republik Indonesia.Makam Sultan Syarif Kasim II terletak di tengah Kota Siak Sri Indrapura tepatnya di samping Mesjid Sultan yaitu Mesjid Syahabuddin.\n" +
                "\n" +
                "Diawal Pemerintahan Republik Indonesia, Kabupaten Siak ini merupakan Wilayah Kewedanan Siak di bawah Kabupaten Bengkalis yang kemudian berubah status menjadi Kecamatan Siak. Barulah pada tahun 1999 berubah menjadi Kabupaten Siak dengan ibukotanya Siak Sri Indrapura berdasarkan UU No. 53 Tahun 1999.')");
        db.execSQL("insert into peninggalan (name, image, content) values ('kerajaan_siak', 'https://www.nativeindonesia.com/wp-content/uploads/2019/10/Patung-perunggu.jpg', 'Aneka koleksi kerajaan Siak yang turun temurun dimiliki kerajaan juga tersusun rapi di dalam dan di luar lemari-lemari kaca. Salah satunya adalah patung perunggu Ratu Wihemina, yang merupakan hadiah dari Kerajaan Belanda. Selain itu terdapat patung pualam Sultan Syarif Hasim I bermata berlian.\n" +
                "\n" +
                "Salah satu yang unik dari sekian banyak barang-barang kerajaan Siak adalah sejenis gramofon raksasa terbuat dari tembaga. Alat ini dimainkan menggunakan piringan bergaris tengah sekitar 1 meter dari bahan kuningan.\n" +
                "\n" +
                "Gramofon berbentuk lemari buatan Jerman ini dapat mengeluarkan bunyi-bunyian musik klasik karya Beethoven dan Mozart sesuai piringan yang dimasukkan ke dalam alat gramofon. Keunikan gramofon ini adalah dari jenisnya yaitu gramofon vertikal dimana piringan gramofon berdiri, tidak seperti lazimnya gramofon horizontal dengan piringan mendatar. Perkakas kerajaan seperti sendok, piring, gelas-cangkir masih terdapat dalam Istana ini. Juga guci-guci besar yang indah memancarkan warna lukisan khas dari China yang mempercantik pemandangan sudut-sudut ruangan. Untuk mengetahui siapa saja tokoh-tokoh Kerajaan Siak di masa lalu, pengunjung dapat melihat melalui foto-foto berukuran besar yang terletak di dalam Istana Siak.')");
        db.execSQL("insert into galeri (name, image) values ('kerajaan_siak', 'https://kesbangpol.riau.go.id/artikel/kerajaan%20Siak.jpg')");
        db.execSQL("insert into galeri (name, image) values ('kerajaan_siak', 'https://4.bp.blogspot.com/-NDfL5BXEpDw/WseFP1DdMhI/AAAAAAAAGNs/KOuyI84C7HI7Tilujq8jWcg-XK6_ChhqQCLcBGAs/s1600/Kapal%2BKato%2BKerajaan%2BSiak%2BSri%2BIndrapura.png')");
        db.execSQL("insert into galeri (name, image) values ('kerajaan_siak', 'https://arifcintaselvia.files.wordpress.com/2011/05/lambang-kerajaan.jpg')");
        db.execSQL("insert into galeri (name, image) values ('kerajaan_siak', 'https://petualang.travelingyuk.com/unggah/2019/09/img_20180508_145417_hdr_01_7er.jpeg')");
        db.execSQL("insert into galeri (name, image) values ('kerajaan_siak', 'https://2.bp.blogspot.com/_D4uUxJxFP_A/TKiaWrnGx0I/AAAAAAAAAHY/OzOXYcVAheo/s280/KO5.jpeg')");
        db.execSQL("insert into galeri (name, image) values ('kerajaan_siak', 'https://awsimages.detik.net.id/customthumb/2015/08/01/1384/154842_siak7.jpg?w=900&q=80')");
        db.execSQL("insert into galeri (name, image) values ('kerajaan_siak', 'https://kebudayaan.kemdikbud.go.id/dpk/wp-content/uploads/sites/5/2017/09/Balai-Kerapatan-Tinggi.jpg')");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists katalog");
        onCreate(db);
    }
}

package com.example.monitoringkebakaranhutan;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;

import android.app.ProgressDialog;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.List;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {
    public static MapsActivity instance;
    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        instance = this;
        setContentView( R.layout.activity_maps );
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById( R.id.map );
        mapFragment.getMapAsync( this );
    }

    public static double[][] mapArray(){
        double a [][] = new double [2][2];
        a[0][0] = 0.825136;
        a[0][1] = 100.422593;
        a[1][0] = 0.954678;
        a[1][1] = 100.387592;
        return a;
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        double lastLatitude = Tool.read(this, "last_latitude", 0d);
        double lastLongitude = Tool.read(this, "last_longitude", 0d);
        if (lastLatitude == 0 && lastLongitude == 0) {
            LatLng latLng = new LatLng(0.8932172, 99.9300584);
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15.0f));
        } else {
            LatLng latLng = new LatLng(lastLatitude, lastLongitude);
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15.0f));
        }
        getData();
        mMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {

            @Override
            public void onInfoWindowClick(Marker marker) {
                /*JSONObject data = (JSONObject)marker.getTag();
                String uuid = Tool.getString(data, "uuid", "").trim();
                String status = Tool.getString(data, "status", "").trim();
                if (status.equals("terbakar")) {
                    FirebaseDatabase.getInstance().getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                            .child("Data_Kebakaran").child(uuid).child("status").setValue("proses");
                    Tool.sendMessage("Pembaruan data kebakaran hutan", "Klik untuk melihat data kebakaran hutan terbaru", "/topics/admin");
                    getData();
                } else if (status.equals("proses")) {
                    FirebaseDatabase.getInstance().getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                            .child("Data_Kebakaran").child(uuid).child("status").setValue("padam");
                    Tool.sendMessage("Pembaruan data kebakaran hutan", "Klik untuk melihat data kebakaran hutan terbaru", "/topics/admin");
                    getData();
                }*/
            }
        });
        mMap.setInfoWindowAdapter(new GoogleMap.InfoWindowAdapter() {

            @Override
            public View getInfoWindow(Marker marker) {
                return null;
            }

            @Override
            public View getInfoContents(Marker marker) {
                View view = LayoutInflater.from(MapsActivity.this).inflate(R.layout.map_marker_tooltip, null);
                TextView locationNameView = view.findViewById(R.id.location_name);
                TextView dateView = view.findViewById(R.id.date);
                final TextView statusView = view.findViewById(R.id.status);
                final Button padam = view.findViewById(R.id.padam);
                JSONObject data = (JSONObject)marker.getTag();
                final String uuid = Tool.getString(data, "uuid", "").trim();
                double lat = Tool.getDouble(data, "lokasiKebakaranLat", 0);
                double lng = Tool.getDouble(data, "lokasiKebakaranLng", 0);
                String location = Tool.getString(data, "lokasiKebakaran", "").trim();
                locationNameView.setText(location);
                try {
                    dateView.setText(Html.fromHtml("<font color='#888888'>"+getResources().getString(R.string.text5)+" "+new SimpleDateFormat("d MMMM yyyy").format(
                            new SimpleDateFormat("yyyy-MM-dd").parse(
                                    Tool.getString(data, "date", "").trim()).getTime()
                    )+"</font>"));
                } catch (Exception e) {
                    e.printStackTrace();
                }
                String status = Tool.getString(data, "status", "").trim();
                /*if (status.equals("terbakar")) {
                    statusView.setText(Html.fromHtml("<b><font color='#000000'>Status:</font> <font color='#e74c3c'>"+getResources().getString(R.string.burnt)+"</font></b>"));
                    padam.setText(R.string.text6);
                    padam.setVisibility(View.VISIBLE);
                } else if (status.equals("proses")) {
                    statusView.setText(Html.fromHtml("<b><font color='#000000'>Status:</font> <font color='#3498db'>"+getResources().getString(R.string.process)+"</font></b>"));
                    padam.setText(R.string.text7);
                    padam.setVisibility(View.VISIBLE);
                } else if (status.equals("padam")) {
                    statusView.setText(Html.fromHtml("<b><font color='#000000'>Status:</font> <font color='#3498db'>"+getResources().getString(R.string.go_out)+"</font></b>"));
                    padam.setVisibility(View.GONE);
                }*/
                return view;
            }
        });
        /*
        LatLng rambahSamo= new LatLng( 0.825136, 100.422593 );
        mMap.addMarker(new MarkerOptions().icon( BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)).position(rambahSamo).title( "Rambah Samo" )
                .snippet( "Hutan terbakar pada tanggal 22 April 2014" ));
        mMap.moveCamera( CameraUpdateFactory.newLatLngZoom(rambahSamo , 10 ) );

        LatLng muaraRumbai= new LatLng( 0.954678, 100.387592 );
        mMap.addMarker(new MarkerOptions().icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)).position(muaraRumbai).title( "Muara Rumbai" )
                .snippet( "Hutan terbakar pada tanggal 17 Mei 2015" ));
        mMap.moveCamera( CameraUpdateFactory.newLatLngZoom(muaraRumbai , 10 ) );

        LatLng daluDalu= new LatLng( 1.082421,100.245665 );
        mMap.addMarker(new MarkerOptions().icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)).position(daluDalu).title( "Dalu Dalu" )
                .snippet( "Hutan terbakar pada tanggal 20 Juni 2013" ));
        mMap.moveCamera( CameraUpdateFactory.newLatLngZoom(daluDalu , 10 ) );

        LatLng ujungBatu= new LatLng( 0.675557, 100.528117 );
        mMap.addMarker(new MarkerOptions().icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)).position(ujungBatu).title( "Ujung Batu" )
                .snippet( "Hutan terbakar pada tanggal 10 Maret 2017" ));
        mMap.moveCamera( CameraUpdateFactory.newLatLngZoom(ujungBatu , 10 ) );

        LatLng RokanHulu = new LatLng( 0.895651, 100.308816 );
        mMap.addMarker( new MarkerOptions().position( RokanHulu ).title( "Kab. Rokan Hulu" ).snippet( " Riau " ) );
        mMap.moveCamera( CameraUpdateFactory.newLatLngZoom( RokanHulu,10 ) );

         */
    }

    public void getData() {
        mMap.clear();
        final ProgressDialog dialog = Tool.createDialog(this, R.string.loading_data);
        dialog.show();
        FirebaseDatabase.getInstance().getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                .child("Data_Kebakaran").addListenerForSingleValueEvent(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                dialog.dismiss();
                int i = 0;
                for (DataSnapshot snapshot:dataSnapshot.getChildren()) {
                    String dataKebakaranUUID = snapshot.getKey();
                    String date = "";
                    String jam = "";
                    String lokasiKebakaran = "";
                    double lokasiKebakaranLat = 0;
                    double lokasiKebakaranLng = 0;
                    String noTelp = "";
                    String penyebabKebakaran = "";
                    String status = "";
                    for (DataSnapshot snapshot2:snapshot.getChildren()) {
                        if (snapshot2.getKey().equals("date")) {
                            date = snapshot2.getValue(String.class);
                        } else if (snapshot2.getKey().equals("jam")) {
                            jam = snapshot2.getValue(String.class);
                        } else if (snapshot2.getKey().equals("lokasiKebakaran")) {
                            lokasiKebakaran = snapshot2.getValue(String.class);
                        } else if (snapshot2.getKey().equals("lokasiKebakaranLat")) {
                            lokasiKebakaranLat = snapshot2.getValue(Double.class);
                        } else if (snapshot2.getKey().equals("lokasiKebakaranLng")) {
                            lokasiKebakaranLng = snapshot2.getValue(Double.class);
                        } else if (snapshot2.getKey().equals("noTelp")) {
                            noTelp = snapshot2.getValue(String.class);
                        } else if (snapshot2.getKey().equals("penyebabKebakaran")) {
                            penyebabKebakaran = snapshot2.getValue(String.class);
                        } else if (snapshot2.getKey().equals("status")) {
                            status = snapshot2.getValue(String.class);
                        }
                    }
                    LatLng latLng = new LatLng(lokasiKebakaranLat, lokasiKebakaranLng);
                    Marker marker = null;
                    if (status.equals("terbakar")) {
                        marker = mMap.addMarker(new MarkerOptions().title(lokasiKebakaran).position(latLng).icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)));
                    } else if (status.equals("proses")) {
                        marker = mMap.addMarker(new MarkerOptions().title(lokasiKebakaran).position(latLng).icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE)));
                    } else if (status.equals("padam")) {
                        marker = mMap.addMarker(new MarkerOptions().title(lokasiKebakaran).position(latLng).icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));
                    }
                    if (marker != null) {
                        try {
                            JSONObject data = new JSONObject();
                            data.put("uuid", dataKebakaranUUID);
                            data.put("date", date);
                            data.put("jam", jam);
                            data.put("lokasiKebakaran", lokasiKebakaran);
                            data.put("lokasiKebakaranLat", lokasiKebakaranLat);
                            data.put("lokasiKebakaranLng", lokasiKebakaranLng);
                            data.put("noTelp", noTelp);
                            data.put("penyebabKebakaran", penyebabKebakaran);
                            data.put("status", status);
                            marker.setTag(data);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    i++;
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }
}

package com.example.monitoringkebakaranhutan;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.MultipartBuilder;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;

import org.json.JSONObject;

import java.util.concurrent.TimeUnit;

public class Tool {

    public static void log(String message) {
        Log.e(Build.MODEL, message);
    }

    public static String read(Context ctx, String name, String defaultValue) {
        SharedPreferences sp = ctx.getSharedPreferences("data", Context.MODE_PRIVATE);
        return sp.getString(name, defaultValue);
    }

    public static void write(Context ctx, String name, String value) {
        SharedPreferences sp = ctx.getSharedPreferences("data", Context.MODE_PRIVATE);
        SharedPreferences.Editor e = sp.edit();
        e.putString(name, value);
        e.commit();
    }

    public static double read(Context ctx, String name, double defaultValue) {
        SharedPreferences sp = ctx.getSharedPreferences("data", Context.MODE_PRIVATE);
        return Double.parseDouble(sp.getString(name, ""+defaultValue));
    }

    public static void write(Context ctx, String name, double value) {
        SharedPreferences sp = ctx.getSharedPreferences("data", Context.MODE_PRIVATE);
        SharedPreferences.Editor e = sp.edit();
        e.putString(name, ""+value);
        e.commit();
    }

    public static String getString(JSONObject obj, String name, String defaultValue) {
        try {
            String value = obj.getString(name);
            if (value == null) {
                return defaultValue;
            }
            return value;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return defaultValue;
    }

    public static double getDouble(JSONObject obj, String name, double defaultValue) {
        try {
            double value = obj.getDouble(name);
            return value;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return defaultValue;
    }

    public static void show(Context ctx, String message) {
        Toast.makeText(ctx, message, Toast.LENGTH_SHORT).show();
    }

    public static void show(Context ctx, int message) {
        Toast.makeText(ctx, message, Toast.LENGTH_SHORT).show();
    }

    public static ProgressDialog createDialog(Context ctx, String message) {
        ProgressDialog dialog = new ProgressDialog(ctx);
        dialog.setCancelable(false);
        dialog.setMessage(message);
        return dialog;
    }

    public static ProgressDialog createDialog(Context ctx, int message) {
        ProgressDialog dialog = new ProgressDialog(ctx);
        dialog.setCancelable(false);
        dialog.setMessage(ctx.getResources().getString(message));
        return dialog;
    }

    public interface LocationListener {

        void onNewLocation(double lat, double lng);
    }

    @SuppressLint("MissingPermission")
    public static void getCurrentLocation(Context ctx, final LocationListener listener) {
        LocationManager mgr = (LocationManager)ctx.getSystemService(Context.LOCATION_SERVICE);
        Location location = mgr.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        if (location == null) {
            location = mgr.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
        }
        if (location == null) {
            mgr.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, new android.location.LocationListener() {

                @Override
                public void onLocationChanged(@NonNull Location location) {
                    if (listener != null) {
                        listener.onNewLocation(location.getLatitude(), location.getLongitude());
                    }
                }

                @Override
                public void onStatusChanged(String provider, int status, Bundle extras) {

                }

                @Override
                public void onProviderEnabled(@NonNull String provider) {

                }

                @Override
                public void onProviderDisabled(@NonNull String provider) {

                }
            });
        } else {
            if (listener != null) {
                listener.onNewLocation(location.getLatitude(), location.getLongitude());
            }
        }
    }

    public static void run(Runnable runnable) {
        new Thread(runnable).start();
    }

    public static void runLater(Runnable runnable) {
        new Handler(Looper.getMainLooper()).post(runnable);
    }

    public static void sendMessage(final String title, final String body, final String token) {
        run(new Runnable() {

            @Override
            public void run() {
                try {
                    OkHttpClient client = new OkHttpClient();
                    client.setConnectTimeout(60, TimeUnit.SECONDS);
                    client.setReadTimeout(60, TimeUnit.SECONDS);
                    client.setWriteTimeout(60, TimeUnit.SECONDS);
                    JSONObject data = new JSONObject();
                    data.put("to", token);
                    JSONObject notification = new JSONObject();
                    notification.put("title", title);
                    notification.put("body", body);
                    notification.put("sound", "default");
                    notification.put("badge", "1");
                    data.put("notification", notification);
                    data.put("priority", "high");
                    RequestBody params = RequestBody.create(MediaType.parse("application/json"), data.toString());
                    Request request = new Request.Builder()
                            .url("https://fcm.googleapis.com/fcm/send")
                            .addHeader("Content-Type", "application/json")
                            .addHeader("Authorization", "key=AAAA9p9VyVc:APA91bH3Eb8SS1FitsuF9Pckx4XBWMfpsttNvnqBkgYAKgXw-m6Zjcoee268EkqTJzvZZGnhbsrvr-E1GkZmPSL-tw818TWZKEumj0vMYs45umQhKQXtHKe6B0sTEDfjk4cupPgSasj4")
                            .post(params)
                            .build();
                    final String response = client.newCall(request).execute().body().string();
                    Tool.log(response);
                    runLater(new Runnable() {

                        @Override
                        public void run() {
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}

package com.example.monitoringkebakaranhutan;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class MyFirebaseMessagingService extends FirebaseMessagingService {

    @Override
    public void onMessageReceived(@NonNull final RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);
        Tool.runLater(new Runnable() {

            @Override
            public void run() {
                try {
                    NotificationManager mgr = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(MyFirebaseMessagingService.this,
                            getPackageName()+".NOTIFICATIONS");
                    builder.setContentTitle(remoteMessage.getData().get("title"));
                    builder.setContentText(remoteMessage.getData().get("body"));
                    builder.setPriority(NotificationCompat.PRIORITY_DEFAULT);
                    builder.setAutoCancel(true);
                    builder.setSmallIcon(R.mipmap.ic_launcher_round);
                    Intent i = new Intent(MyFirebaseMessagingService.this, MapsActivity.class);
                    builder.setContentIntent(PendingIntent.getActivity(MyFirebaseMessagingService.this, 0, i, PendingIntent.FLAG_UPDATE_CURRENT));
                    mgr.notify((int)System.currentTimeMillis(), builder.build());
                    MapsActivity.instance.getData();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}

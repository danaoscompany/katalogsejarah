package com.dn.katalogsejarahadmin.fragments;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dn.katalogsejarahadmin.AddGaleriActivity;
import com.dn.katalogsejarahadmin.EditGaleriActivity;
import com.dn.katalogsejarahadmin.HomeActivity;
import com.dn.katalogsejarahadmin.R;
import com.dn.katalogsejarahadmin.Util;
import com.dn.katalogsejarahadmin.adapter.GaleriAdapter;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONObject;

import java.util.ArrayList;

public class GaleriFragment extends Fragment {
    private final int PICK_IMAGE_FROM_GALLERY = 1;
    private final int ADD_GALERI = 2;
    private final int EDIT_GALERI = 3;
    View view;
    HomeActivity activity;
    RecyclerView galleryList;
    ArrayList<JSONObject> galleries;
    GaleriAdapter adapter;
    LinearLayout progress;
    FloatingActionButton add;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_galeri, container, false);
        galleryList = view.findViewById(R.id.galleries);
        progress = view.findViewById(R.id.progress);
        add = view.findViewById(R.id.add);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        activity = (HomeActivity)getActivity();
        galleryList.setLayoutManager(new LinearLayoutManager(activity));
        galleryList.setItemAnimator(new DefaultItemAnimator());
        galleries = new ArrayList<>();
        adapter = new GaleriAdapter(activity, galleries, new GaleriAdapter.Listener() {

            @Override
            public void onGalleryEdited(int position, JSONObject gallery) {
                Intent i = new Intent(activity, EditGaleriActivity.class);
                i.putExtra("uuid", Util.getString(gallery, "uuid", "").trim());
                i.putExtra("galeri_uuid", Util.getString(gallery, "galeri_uuid", "").trim());
                startActivityForResult(i, EDIT_GALERI);
            }

            @Override
            public void onGalleryDeleted(int position, JSONObject gallery) {
                new AlertDialog.Builder(activity)
                        .setMessage(R.string.text28)
                        .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialogInterface, int which) {
                                final ProgressDialog dialog = activity.createDialog(R.string.text29);
                                dialog.show();
                                FirebaseDatabase.getInstance().getReference("galeri")
                                        .child(Util.getString(gallery, "uuid", "").trim())
                                        .child(Util.getString(gallery, "galeri_uuid", "").trim())
                                        .removeValue()
                                        .addOnSuccessListener(new OnSuccessListener<Void>() {

                                            @Override
                                            public void onSuccess(Void aVoid) {
                                                dialog.dismiss();
                                                getGallery();
                                            }
                                        });
                            }
                        })
                        .setNegativeButton(R.string.no, null)
                        .create()
                        .show();
            }
        });
        galleryList.setAdapter(adapter);
        add.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(activity, AddGaleriActivity.class), ADD_GALERI);
            }
        });
        getGallery();
    }

    public void getGallery() {
        galleries.clear();
        adapter.notifyDataSetChanged();
        progress.setVisibility(View.VISIBLE);
        FirebaseDatabase.getInstance().getReference("galeri").orderByChild("name").equalTo("kerajaan_siak")
                .addListenerForSingleValueEvent(new ValueEventListener() {

                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.getChildrenCount() > 0) {
                            for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                String uuid = snapshot.getKey();
                                String name = "";
                                for (DataSnapshot snapshot2 : snapshot.getChildren()) {
                                    if (snapshot2.getKey().equals("name")) {
                                        name = snapshot2.getValue(String.class);
                                    }
                                }
                                if (name.equals("kerajaan_siak")) {
                                    for (DataSnapshot snapshot2 : snapshot.getChildren()) {
                                        if (!snapshot2.getKey().equals("name")) {
                                            String galeriUUID = snapshot2.getKey();
                                            String content = "";
                                            String image = "";
                                            for (DataSnapshot snapshot3 : snapshot2.getChildren()) {
                                                if (snapshot3.getKey().equals("content")) {
                                                    content = snapshot3.getValue(String.class);
                                                } else if (snapshot3.getKey().equals("image")) {
                                                    image = snapshot3.getValue(String.class);
                                                }
                                            }
                                            try {
                                                JSONObject galeri = new JSONObject();
                                                galeri.put("uuid", uuid);
                                                galeri.put("galeri_uuid", galeriUUID);
                                                galeri.put("content", content);
                                                galeri.put("image", image);
                                                galleries.add(galeri);
                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    }
                                    adapter.notifyDataSetChanged();
                                    progress.setVisibility(View.GONE);
                                }
                            }
                        } else {
                            progress.setVisibility(View.GONE);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == ADD_GALERI) {
                getGallery();
            } else if (requestCode == EDIT_GALERI) {
                getGallery();
            }
        }
    }
}

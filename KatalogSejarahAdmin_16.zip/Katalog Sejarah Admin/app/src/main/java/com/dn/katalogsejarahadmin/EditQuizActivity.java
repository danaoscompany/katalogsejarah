package com.dn.katalogsejarahadmin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.UUID;

public class EditQuizActivity extends BaseActivity {
    String uuid = "";
    String questionUUID = "";
    EditText questionField, answer1Field, answer2Field, answer3Field, answer4Field;
    Spinner correctAnswerList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_quiz);
        setTitle(R.string.edit_quiz);
        setSupportActionBar((Toolbar)findViewById(R.id.toolbar));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        uuid = getIntent().getStringExtra("uuid");
        questionUUID = getIntent().getStringExtra("question_uuid");
        questionField = findViewById(R.id.question);
        answer1Field = findViewById(R.id.answer_1);
        answer2Field = findViewById(R.id.answer_2);
        answer3Field = findViewById(R.id.answer_3);
        answer4Field = findViewById(R.id.answer_4);
        correctAnswerList = findViewById(R.id.correct_answer);
        String[] correctAnswers = new String[] {
                "A", "B", "C", "D"
        };
        ArrayAdapter<String> correctAnswerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, correctAnswers);
        correctAnswerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        correctAnswerList.setAdapter(correctAnswerAdapter);
        final ProgressDialog dialog = createDialog(R.string.loading);
        dialog.show();
        FirebaseDatabase.getInstance().getReference("quiz").child(uuid).child("questions").child(questionUUID)
                .addListenerForSingleValueEvent(new ValueEventListener() {

                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot snapshot:dataSnapshot.getChildren()) {
                            if (snapshot.getKey().equals("question")) {
                                questionField.setText(snapshot.getValue(String.class));
                            } else if (snapshot.getKey().equals("answers")) {
                                for (DataSnapshot snapshot2:snapshot.getChildren()) {
                                    if (snapshot2.getKey().equals("answer_1")) {
                                        answer1Field.setText(snapshot2.getValue(String.class));
                                    } else if (snapshot2.getKey().equals("answer_2")) {
                                        answer2Field.setText(snapshot2.getValue(String.class));
                                    } else if (snapshot2.getKey().equals("answer_3")) {
                                        answer3Field.setText(snapshot2.getValue(String.class));
                                    } else if (snapshot2.getKey().equals("answer_4")) {
                                        answer4Field.setText(snapshot2.getValue(String.class));
                                    } else if (snapshot2.getKey().equals("correct")) {
                                        String correctAnswer = snapshot2.getValue(String.class);
                                        if (correctAnswer.equals("answer_1")) {
                                            correctAnswerList.setSelection(0);
                                        } else if (correctAnswer.equals("answer_2")) {
                                            correctAnswerList.setSelection(1);
                                        } else if (correctAnswer.equals("answer_3")) {
                                            correctAnswerList.setSelection(2);
                                        } else if (correctAnswer.equals("answer_4")) {
                                            correctAnswerList.setSelection(3);
                                        }
                                    }
                                }
                            }
                        }
                        dialog.dismiss();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
    }

    public void save(View view) {
        final String question = questionField.getText().toString().trim();
        final String answer1 = answer1Field.getText().toString().trim();
        final String answer2 = answer2Field.getText().toString().trim();
        final String answer3 = answer3Field.getText().toString().trim();
        final String answer4 = answer4Field.getText().toString().trim();
        final int correctAnswer = correctAnswerList.getSelectedItemPosition();
        if (question.equals("")) {
            show(R.string.text21);
            return;
        }
        if (answer1.equals("") || answer2.equals("") || answer3.equals("") || answer4.equals("")) {
            show(R.string.text22);
            return;
        }
        final ProgressDialog dialog = createDialog(R.string.text24);
        dialog.show();
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("quiz").child(uuid).child("questions").child(questionUUID);
        ref.child("question").setValue(question).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                DatabaseReference ref2 = ref.child("answers");
                ref2.child("answer_1").setValue(answer1).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        ref2.child("answer_2").setValue(answer2).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                ref2.child("answer_3").setValue(answer3).addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        ref2.child("answer_4").setValue(answer4).addOnSuccessListener(new OnSuccessListener<Void>() {
                                            @Override
                                            public void onSuccess(Void aVoid) {
                                                ref2.child("correct").setValue(correctAnswer==0?"answer_1":correctAnswer==1?"answer_2":correctAnswer==2?"answer_3":correctAnswer==3?"answer_4":"")
                                                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                            @Override
                                                            public void onSuccess(Void aVoid) {
                                                                dialog.dismiss();
                                                                setResult(RESULT_OK);
                                                                finish();
                                                            }
                                                });
                                            }
                                        });
                                    }
                                });
                            }
                        });
                    }
                });
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            finish();
        }
        return false;
    }
}
package com.dn.katalogsejarahadmin.adapter;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.dn.katalogsejarahadmin.R;
import com.dn.katalogsejarahadmin.Util;
import com.squareup.picasso.Picasso;

import org.json.JSONObject;

import java.util.ArrayList;

public class VideoAdapter extends RecyclerView.Adapter<VideoAdapter.ViewHolder> {
    Context context;
    ArrayList<JSONObject> videos;
    Listener listener;

    public VideoAdapter(Context ctx, ArrayList<JSONObject> videos, Listener listener) {
        this.context = ctx;
        this.videos = videos;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.video, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        try {
            final JSONObject video = videos.get(position);
            String image = Util.getString(video, "screenshot", "").trim();
            if (!image.equals("")) {
                Picasso.get().load(Uri.parse(image)).resize(256, 0).onlyScaleDown().into(holder.imgView);
            } else {
                holder.imgView.setImageResource(R.drawable.img_placeholder);
            }
            holder.contentView.setText(Util.getString(video, "content", ""));
            holder.play.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        listener.onVideoPlayed(position, video);
                    }
                }
            });
            holder.edit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        listener.onVideoEdited(position, video);
                    }
                }
            });
            holder.delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        listener.onVideoDeleted(position, video);
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return videos.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView imgView;
        public TextView contentView;
        public Button play, edit, delete;

        public ViewHolder(View view) {
            super(view);
            imgView = view.findViewById(R.id.img);
            contentView = view.findViewById(R.id.content);
            play = view.findViewById(R.id.play);
            edit = view.findViewById(R.id.edit);
            delete = view.findViewById(R.id.delete);
        }
    }

    public interface Listener {

        void onVideoPlayed(int position, JSONObject gallery);
        void onVideoEdited(int position, JSONObject gallery);
        void onVideoDeleted(int position, JSONObject gallery);
    }
}

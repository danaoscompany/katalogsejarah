package com.dn.katalogsejarahadmin;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;

import com.dn.katalogsejarahadmin.fragments.GaleriFragment;
import com.dn.katalogsejarahadmin.fragments.MapFragment;
import com.dn.katalogsejarahadmin.fragments.PeninggalanFragment;
import com.dn.katalogsejarahadmin.fragments.QuizFragment;
import com.dn.katalogsejarahadmin.fragments.SejarahFragment;
import com.dn.katalogsejarahadmin.fragments.VideoFragment;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.ListResult;
import com.google.firebase.storage.StorageReference;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.core.view.GravityCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;

public class HomeActivity extends BaseActivity {
    SejarahFragment sejarahFragment;
    PeninggalanFragment peninggalanFragment;
    GaleriFragment galeriFragment;
    VideoFragment videoFragment;
    QuizFragment quizFragment;
    MapFragment mapFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setItemIconTintList(null);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {
                drawer.closeDrawer((int) GravityCompat.START);
                int id = menuItem.getItemId();
                if (id == R.id.nav_history) {
                    selectFragment(sejarahFragment);
                } else if (id == R.id.nav_relics) {
                    selectFragment(peninggalanFragment);
                } else if (id == R.id.nav_gallery) {
                    selectFragment(galeriFragment);
                } else if (id == R.id.nav_video) {
                    selectFragment(videoFragment);
                } else if (id == R.id.nav_quiz) {
                    selectFragment(quizFragment);
                } else if (id == R.id.nav_map) {
                    selectFragment(mapFragment);
                } else if (id == R.id.nav_logout) {
                    new AlertDialog.Builder(HomeActivity.this)
                            .setMessage(R.string.text25)
                            .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    write("email", "");
                                    write("password", "");
                                    startActivity(new Intent(HomeActivity.this, MainActivity.class));
                                    finish();
                                }
                            })
                            .setNegativeButton(R.string.no, null)
                            .create()
                            .show();
                }
                return false;
            }
        });
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.open_drawer, R.string.close_drawer) {

            public void onDrawerClosed(View view) {
                super.onDrawerClosed(view);
            }

            public void onDrawerOpened(View view) {
                super.onDrawerOpened(view);
            }
        };
        drawer.setDrawerListener(toggle);
        toggle.syncState();
        sejarahFragment = new SejarahFragment();
        peninggalanFragment = new PeninggalanFragment();
        galeriFragment = new GaleriFragment();
        videoFragment = new VideoFragment();
        quizFragment = new QuizFragment();
        mapFragment = new MapFragment();
        selectFragment(sejarahFragment);
    }
    
    public void selectFragment(Fragment fr) {
        if (fr instanceof SejarahFragment) {
            setTitle(R.string.history);
        } else if (fr instanceof PeninggalanFragment) {
            setTitle(R.string.relics);
        } else if (fr instanceof GaleriFragment) {
            setTitle(R.string.menu_gallery);
        } else if (fr instanceof VideoFragment) {
            setTitle(R.string.menu_video);
        } else if (fr instanceof QuizFragment) {
            setTitle(R.string.menu_quiz);
        } else if (fr instanceof MapFragment) {
            setTitle(R.string.menu_map);
        }
        getSupportFragmentManager().beginTransaction().replace(R.id.content_main, fr).commit();
    }
}
package com.dn.katalogsejarahadmin.adapter;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.dn.katalogsejarahadmin.R;
import com.dn.katalogsejarahadmin.Util;
import com.squareup.picasso.Picasso;

import org.json.JSONObject;

import java.util.ArrayList;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.ViewHolder> {
    Context context;
    ArrayList<JSONObject> histories;
    Listener listener;

    public HistoryAdapter(Context ctx, ArrayList<JSONObject> histories, Listener listener) {
        this.context = ctx;
        this.histories = histories;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.history, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        try {
            final JSONObject history = histories.get(position);
            String image = Util.getString(history, "image", "").trim();
            if (!image.equals("")) {
                Picasso.get().load(Uri.parse(image)).resize(256, 0).onlyScaleDown().into(holder.imgView);
            } else {
                holder.imgView.setImageResource(R.drawable.img_placeholder);
            }
            holder.contentView.setText(Util.getString(history, "content", ""));
            holder.edit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        listener.onHistoryEdited(position, history);
                    }
                }
            });
            holder.delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        listener.onHistoryDeleted(position, history);
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return histories.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView imgView;
        public TextView contentView;
        public Button edit, delete;

        public ViewHolder(View view) {
            super(view);
            imgView = view.findViewById(R.id.img);
            contentView = view.findViewById(R.id.content);
            edit = view.findViewById(R.id.edit);
            delete = view.findViewById(R.id.delete);
        }
    }

    public interface Listener {

        void onHistoryEdited(int position, JSONObject history);
        void onHistoryDeleted(int position, JSONObject history);
    }
}

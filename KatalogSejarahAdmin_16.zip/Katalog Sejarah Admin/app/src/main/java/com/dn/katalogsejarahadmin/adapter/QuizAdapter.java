package com.dn.katalogsejarahadmin.adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.dn.katalogsejarahadmin.R;
import com.dn.katalogsejarahadmin.Util;

import org.json.JSONObject;

import java.util.ArrayList;

public class QuizAdapter extends RecyclerView.Adapter<QuizAdapter.ViewHolder> {
    Context context;
    ArrayList<JSONObject> quizses;
    Listener listener;

    public QuizAdapter(Context ctx, ArrayList<JSONObject> quizses, Listener listener) {
        this.context = ctx;
        this.quizses = quizses;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.quiz, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        try {
            final JSONObject quiz = quizses.get(position);
            holder.questionView.setText(Util.getString(quiz, "question", ""));
            holder.edit.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        listener.onQuizEdited(position, quiz);
                    }
                }
            });
            holder.delete.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        listener.onQuizDeleted(position, quiz);
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return quizses.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView questionView;
        public Button edit, delete;
        
        public ViewHolder(View view) {
            super(view);
            questionView = view.findViewById(R.id.question);
            edit = view.findViewById(R.id.edit);
            delete = view.findViewById(R.id.delete);
        }
    }

    public interface Listener {

        void onQuizEdited(int position, JSONObject quiz);
        void onQuizDeleted(int position, JSONObject quiz);
    }
}

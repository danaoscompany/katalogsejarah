package com.dn.katalogsejarahadmin;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.File;
import java.util.concurrent.TimeUnit;

public class Util {

    public static void log(String message) {
        Log.e(Build.MODEL, message);
    }

    public static void show(Context ctx, String message) {
        Toast.makeText(ctx, message, Toast.LENGTH_SHORT).show();
    }

    public static void show(Context ctx, int message) {
        Toast.makeText(ctx, message, Toast.LENGTH_SHORT).show();
    }

    public static ProgressDialog createDialog(Context context, String str) {
        ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.setCancelable(false);
        progressDialog.setMessage(str);
        return progressDialog;
    }

    public static ProgressDialog createDialog(Context context, int i) {
        ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.setCancelable(false);
        progressDialog.setMessage(context.getResources().getString(i));
        return progressDialog;
    }

    public static void run(Runnable runnable) {
        new Thread(runnable).start();
    }

    public static void runLater(Runnable runnable) {
        new Handler(Looper.getMainLooper()).post(runnable);
    }

    public static String read(Context ctx, String name, String defaultValue) {
        SharedPreferences sp = ctx.getSharedPreferences("data", Context.MODE_PRIVATE);
        return sp.getString(name, defaultValue);
    }

    public static void write(Context ctx, String name, String value) {
        SharedPreferences sp = ctx.getSharedPreferences("data", Context.MODE_PRIVATE);
        SharedPreferences.Editor e = sp.edit();
        e.putString(name, value);
        e.commit();
    }

    public static String getString(JSONObject jSONObject, String str, String str2) {
        try {
            String string = jSONObject.getString(str);
            return (string == null || string.equals("null") || string.equals("NULL")) ? str2 : string;
        } catch (Exception e) {
            e.printStackTrace();
            return str2;
        }
    }

    public static int getInt(JSONObject jSONObject, String str, int i) {
        try {
            String string = jSONObject.getString(str);
            if (string != null && !string.equals("null")) {
                if (!string.equals("NULL")) {
                    return Integer.parseInt(string);
                }
            }
            return i;
        } catch (Exception e) {
            e.printStackTrace();
            return i;
        }
    }

    public static double getDouble(JSONObject jSONObject, String str, double d) {
        try {
            String string = jSONObject.getString(str);
            if (string != null && !string.equals("null")) {
                if (!string.equals("NULL")) {
                    return Double.parseDouble(string);
                }
            }
            return d;
        } catch (Exception e) {
            e.printStackTrace();
            return d;
        }
    }
}
package com.dn.katalogsejarahadmin.fragments;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.dn.katalogsejarahadmin.HomeActivity;
import com.dn.katalogsejarahadmin.R;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MapFragment extends Fragment {
    View view;
    HomeActivity activity;
    GoogleMap map;
    double selectedLat = 0;
    double selectedLng = 0;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_map, container, false);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        activity = (HomeActivity)getActivity();
        SupportMapFragment mf = (SupportMapFragment)getChildFragmentManager().findFragmentById(R.id.map);
        mf.getMapAsync(new OnMapReadyCallback() {

            @Override
            public void onMapReady(GoogleMap googleMap) {
                map = googleMap;
                map.setOnMapClickListener(new GoogleMap.OnMapClickListener() {

                    @Override
                    public void onMapClick(LatLng latLng) {
                        selectedLat = latLng.latitude;
                        selectedLng = latLng.longitude;
                        map.clear();
                        map.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15.0f));
                        map.addMarker(new MarkerOptions().position(latLng).icon(BitmapDescriptorFactory.defaultMarker()));
                    }
                });
                FirebaseDatabase.getInstance().getReference("lokasi").orderByChild("name").equalTo("kerajaan_siak")
                        .addListenerForSingleValueEvent(new ValueEventListener() {

                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                for (DataSnapshot snapshot:dataSnapshot.getChildren()) {
                                    String uuid = snapshot.getKey();
                                    String name = "";
                                    double lat = 0;
                                    double lng = 0;
                                    for (DataSnapshot snapshot2:snapshot.getChildren()) {
                                        if (snapshot2.getKey().equals("name")) {
                                            name = snapshot2.getValue(String.class);
                                        } else if (snapshot2.getKey().equals("lat")) {
                                            lat = snapshot2.getValue(Double.class);
                                        } else if (snapshot2.getKey().equals("lng")) {
                                            lng = snapshot2.getValue(Double.class);
                                        }
                                    }
                                    if (name.equals("kerajaan_siak")) {
                                        selectedLat = lat;
                                        selectedLng = lng;
                                        LatLng latLng = new LatLng(lat, lng);
                                        map.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15.0f));
                                        map.addMarker(new MarkerOptions().position(latLng).icon(BitmapDescriptorFactory.defaultMarker()));
                                    }
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                            }
                        });
            }
        });
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.map, menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.set) {
            final ProgressDialog dialog = activity.createDialog(R.string.setting_location);
            dialog.show();
            FirebaseDatabase.getInstance().getReference("lokasi").orderByChild("name").equalTo("kerajaan_siak")
                    .addListenerForSingleValueEvent(new ValueEventListener() {

                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            for (DataSnapshot snapshot:dataSnapshot.getChildren()) {
                                String uuid = snapshot.getKey();
                                DatabaseReference ref = FirebaseDatabase.getInstance().getReference("lokasi").child(uuid);
                                ref.child("lat").setValue(selectedLat).addOnSuccessListener(new OnSuccessListener<Void>() {

                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        ref.child("lng").setValue(selectedLng).addOnSuccessListener(new OnSuccessListener<Void>() {

                                            @Override
                                            public void onSuccess(Void aVoid) {
                                                dialog.dismiss();
                                                activity.show(R.string.text26);
                                            }
                                        });
                                    }
                                });
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                        }
                    });
        }
        return false;
    }
}

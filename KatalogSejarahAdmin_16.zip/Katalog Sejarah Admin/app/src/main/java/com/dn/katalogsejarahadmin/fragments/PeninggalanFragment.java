package com.dn.katalogsejarahadmin.fragments;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dn.katalogsejarahadmin.AddPeninggalanActivity;
import com.dn.katalogsejarahadmin.EditPeninggalanActivity;
import com.dn.katalogsejarahadmin.HomeActivity;
import com.dn.katalogsejarahadmin.R;
import com.dn.katalogsejarahadmin.Util;
import com.dn.katalogsejarahadmin.adapter.PeninggalanAdapter;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONObject;

import java.util.ArrayList;

public class PeninggalanFragment extends Fragment {
    private final int PICK_IMAGE_FROM_GALLERY = 1;
    private final int ADD_PENINGGALAN = 2;
    private final int EDIT_PENINGGALAN = 3;
    View view;
    HomeActivity activity;
    RecyclerView peninggalanList;
    ArrayList<JSONObject> histories;
    PeninggalanAdapter adapter;
    LinearLayout progress;
    FloatingActionButton add;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_peninggalan, container, false);
        peninggalanList = view.findViewById(R.id.histories);
        progress = view.findViewById(R.id.progress);
        add = view.findViewById(R.id.add);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        activity = (HomeActivity)getActivity();
        peninggalanList.setLayoutManager(new LinearLayoutManager(activity));
        peninggalanList.setItemAnimator(new DefaultItemAnimator());
        histories = new ArrayList<>();
        adapter = new PeninggalanAdapter(activity, histories, new PeninggalanAdapter.Listener() {

            @Override
            public void onPeninggalanEdited(int position, JSONObject peninggalan) {
                Intent i = new Intent(activity, EditPeninggalanActivity.class);
                i.putExtra("uuid", Util.getString(peninggalan, "uuid", "").trim());
                i.putExtra("peninggalan_uuid", Util.getString(peninggalan, "peninggalan_uuid", "").trim());
                startActivityForResult(i, EDIT_PENINGGALAN);
            }

            @Override
            public void onPeninggalanDeleted(int position, JSONObject peninggalan) {
                new AlertDialog.Builder(activity)
                        .setMessage(R.string.text28)
                        .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialogInterface, int which) {
                                final ProgressDialog dialog = activity.createDialog(R.string.text29);
                                dialog.show();
                                FirebaseDatabase.getInstance().getReference("peninggalan")
                                        .child(Util.getString(peninggalan, "uuid", "").trim())
                                        .child(Util.getString(peninggalan, "peninggalan_uuid", "").trim())
                                        .removeValue()
                                        .addOnSuccessListener(new OnSuccessListener<Void>() {

                                            @Override
                                            public void onSuccess(Void aVoid) {
                                                dialog.dismiss();
                                                getRelics();
                                            }
                                        });
                            }
                        })
                        .setNegativeButton(R.string.no, null)
                        .create()
                        .show();
            }
        });
        peninggalanList.setAdapter(adapter);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(activity, AddPeninggalanActivity.class), ADD_PENINGGALAN);
            }
        });
        getRelics();
    }

    public void getRelics() {
        histories.clear();
        adapter.notifyDataSetChanged();
        progress.setVisibility(View.VISIBLE);
        FirebaseDatabase.getInstance().getReference("peninggalan").orderByChild("name").equalTo("kerajaan_siak")
                .addListenerForSingleValueEvent(new ValueEventListener() {

                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.getChildrenCount() > 0) {
                            for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                String uuid = snapshot.getKey();
                                String name = "";
                                for (DataSnapshot snapshot2 : snapshot.getChildren()) {
                                    if (snapshot2.getKey().equals("name")) {
                                        name = snapshot2.getValue(String.class);
                                    }
                                }
                                if (name.equals("kerajaan_siak")) {
                                    for (DataSnapshot snapshot2 : snapshot.getChildren()) {
                                        if (!snapshot2.getKey().equals("name")) {
                                            String peninggalanUUID = snapshot2.getKey();
                                            String content = "";
                                            String image = "";
                                            for (DataSnapshot snapshot3 : snapshot2.getChildren()) {
                                                if (snapshot3.getKey().equals("content")) {
                                                    content = snapshot3.getValue(String.class);
                                                } else if (snapshot3.getKey().equals("image")) {
                                                    image = snapshot3.getValue(String.class);
                                                }
                                            }
                                            try {
                                                JSONObject peninggalan = new JSONObject();
                                                peninggalan.put("uuid", uuid);
                                                peninggalan.put("peninggalan_uuid", peninggalanUUID);
                                                peninggalan.put("content", content);
                                                peninggalan.put("image", image);
                                                histories.add(peninggalan);
                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    }
                                    adapter.notifyDataSetChanged();
                                    progress.setVisibility(View.GONE);
                                }
                            }
                        } else {
                            progress.setVisibility(View.GONE);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == ADD_PENINGGALAN) {
                getRelics();
            } else if (requestCode == EDIT_PENINGGALAN) {
                getRelics();
            }
        }
    }
}

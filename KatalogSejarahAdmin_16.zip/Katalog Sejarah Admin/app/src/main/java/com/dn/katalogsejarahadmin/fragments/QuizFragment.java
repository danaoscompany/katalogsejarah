package com.dn.katalogsejarahadmin.fragments;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dn.katalogsejarahadmin.AddQuizActivity;
import com.dn.katalogsejarahadmin.EditQuizActivity;
import com.dn.katalogsejarahadmin.HomeActivity;
import com.dn.katalogsejarahadmin.R;
import com.dn.katalogsejarahadmin.Util;
import com.dn.katalogsejarahadmin.adapter.QuizAdapter;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONObject;

import java.util.ArrayList;

public class QuizFragment extends Fragment {
    private final int ADD_QUIZ = 1;
    private final int EDIT_QUIZ = 2;
    View view;
    HomeActivity activity;
    RecyclerView quizList;
    ArrayList<JSONObject> quizes;
    QuizAdapter adapter;
    LinearLayout progress;
    FloatingActionButton add;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_quiz, container, false);
        quizList = view.findViewById(R.id.quiz);
        progress = view.findViewById(R.id.progress);
        add = view.findViewById(R.id.add);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        activity = (HomeActivity)getActivity();
        quizList.setLayoutManager(new LinearLayoutManager(activity));
        quizList.setItemAnimator(new DefaultItemAnimator());
        quizes = new ArrayList<>();
        adapter = new QuizAdapter(activity, quizes, new QuizAdapter.Listener() {

            @Override
            public void onQuizEdited(int position, JSONObject quiz) {
                Intent i = new Intent(activity, EditQuizActivity.class);
                i.putExtra("uuid", Util.getString(quiz, "uuid", "").trim());
                i.putExtra("question_uuid", Util.getString(quiz, "question_uuid", "").trim());
                startActivityForResult(i, EDIT_QUIZ);
            }

            @Override
            public void onQuizDeleted(int position, JSONObject quiz) {
                new AlertDialog.Builder(activity)
                        .setMessage(R.string.text14)
                        .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialogInterface, int which) {
                                final ProgressDialog dialog = activity.createDialog(R.string.text15);
                                dialog.show();
                                String uuid = Util.getString(quiz, "uuid", "").trim();
                                String questionUUID = Util.getString(quiz, "question_uuid", "").trim();
                                FirebaseDatabase.getInstance().getReference("quiz")
                                        .child(uuid)
                                        .child("questions")
                                        .child(questionUUID)
                                        .removeValue()
                                        .addOnSuccessListener(new OnSuccessListener<Void>() {

                                            @Override
                                            public void onSuccess(Void aVoid) {
                                                dialog.dismiss();
                                                getQuizes();
                                            }
                                        })
                                        .addOnFailureListener(new OnFailureListener() {

                                            @Override
                                            public void onFailure(@NonNull Exception e) {
                                                e.printStackTrace();
                                            }
                                        });
                            }
                        })
                        .setNegativeButton(R.string.no, null)
                        .create()
                        .show();
            }
        });
        quizList.setAdapter(adapter);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(activity, AddQuizActivity.class), ADD_QUIZ);
            }
        });
        getQuizes();
    }

    public void getQuizes() {
        quizes.clear();
        adapter.notifyDataSetChanged();
        FirebaseDatabase.getInstance().getReference("quiz").orderByChild("name").equalTo("kerajaan_siak")
                .addListenerForSingleValueEvent(new ValueEventListener() {

                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.getChildrenCount() > 0) {
                            for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                String uuid = snapshot.getKey();
                                for (DataSnapshot snapshot2 : snapshot.getChildren()) {
                                    if (snapshot2.getKey().equals("questions")) {
                                        for (DataSnapshot snapshot3 : snapshot2.getChildren()) {
                                            String questionUUID = snapshot3.getKey();
                                            String question = "";
                                            String answer1 = "";
                                            String answer2 = "";
                                            String answer3 = "";
                                            String answer4 = "";
                                            String correct = "";
                                            for (DataSnapshot snapshot4 : snapshot3.getChildren()) {
                                                if (snapshot4.getKey().equals("question")) {
                                                    question = snapshot4.getValue(String.class);
                                                } else if (snapshot4.getKey().equals("answers")) {
                                                    for (DataSnapshot snapshot5 : snapshot4.getChildren()) {
                                                        if (snapshot5.getKey().equals("answer_1")) {
                                                            answer1 = snapshot5.getValue(String.class);
                                                        } else if (snapshot5.getKey().equals("answer_2")) {
                                                            answer2 = snapshot5.getValue(String.class);
                                                        } else if (snapshot5.getKey().equals("answer_3")) {
                                                            answer3 = snapshot5.getValue(String.class);
                                                        } else if (snapshot5.getKey().equals("answer_4")) {
                                                            answer4 = snapshot5.getValue(String.class);
                                                        } else if (snapshot5.getKey().equals("correct")) {
                                                            correct = snapshot5.getValue(String.class);
                                                        }
                                                    }
                                                }
                                            }
                                            try {
                                                JSONObject quiz = new JSONObject();
                                                quiz.put("uuid", uuid);
                                                quiz.put("question_uuid", questionUUID);
                                                quiz.put("question", question);
                                                quiz.put("answer_1", answer1);
                                                quiz.put("answer_2", answer2);
                                                quiz.put("answer_3", answer3);
                                                quiz.put("answer_4", answer4);
                                                quiz.put("correct", correct);
                                                quizes.add(quiz);
                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    }
                                }
                            }
                            adapter.notifyDataSetChanged();
                            progress.setVisibility(View.GONE);
                        } else {
                            progress.setVisibility(View.GONE);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == ADD_QUIZ) {
                getQuizes();
            } else if (requestCode == EDIT_QUIZ) {
                getQuizes();
            }
        }
    }
}

package com.dn.katalogsejarahadmin;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.UUID;

public class EditSejarahActivity extends BaseActivity {
    private final int PICK_IMAGE_FROM_GALLERY = 1;
    ImageView imgView;
    EditText historyField;
    Button save;
    File selectedImageFile = null;
    String uuid = "";
    String sejarahUUID = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_sejarah);
        setTitle(R.string.edit_sejarah);
        setSupportActionBar((Toolbar)findViewById(R.id.toolbar));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        uuid = getIntent().getStringExtra("uuid");
        sejarahUUID = getIntent().getStringExtra("sejarah_uuid");
        imgView = findViewById(R.id.img);
        historyField = findViewById(R.id.history);
        save = findViewById(R.id.save);
        save.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                final String history = historyField.getText().toString();
                if (history.trim().equals("")) {
                    show(R.string.text10);
                    return;
                }
                final ProgressDialog dialog = Util.createDialog(EditSejarahActivity.this, R.string.saving);
                dialog.show();
                if (selectedImageFile == null) {
                    DatabaseReference ref = FirebaseDatabase.getInstance().getReference("sejarah").child(uuid)
                            .child(sejarahUUID);
                    ref.child("content").setValue(history).addOnSuccessListener(new OnSuccessListener<Void>() {

                        @Override
                        public void onSuccess(Void aVoid) {
                            dialog.dismiss();
                            show(R.string.text11);
                            setResult(Activity.RESULT_OK);
                            finish();
                        }
                    });
                } else {
                    StorageReference ref = FirebaseStorage.getInstance().getReference("sejarah")
                            .child(UUID.randomUUID().toString());
                    ref.putFile(Uri.fromFile(selectedImageFile))
                            .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {

                                @Override
                                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                    ref.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {

                                        @Override
                                        public void onSuccess(Uri uri) {
                                            DatabaseReference ref = FirebaseDatabase.getInstance().getReference("sejarah").child(uuid)
                                                    .child(sejarahUUID);
                                            ref.child("content").setValue(history).addOnSuccessListener(new OnSuccessListener<Void>() {

                                                @Override
                                                public void onSuccess(Void aVoid) {
                                                    ref.child("image").setValue(uri.toString())
                                                            .addOnSuccessListener(new OnSuccessListener<Void>() {

                                                                @Override
                                                                public void onSuccess(Void aVoid) {
                                                                    dialog.dismiss();
                                                                    show(R.string.text11);
                                                                    setResult(Activity.RESULT_OK);
                                                                    finish();
                                                                }
                                                            });
                                                }
                                            });
                                        }
                                    });
                                }
                            });
                }
            }
        });
        final ProgressDialog dialog = createDialog(R.string.loading);
        dialog.show();
        FirebaseDatabase.getInstance().getReference("sejarah").child(uuid).child(sejarahUUID)
                .addListenerForSingleValueEvent(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String content = "";
                String image = "";
                for (DataSnapshot snapshot:dataSnapshot.getChildren()) {
                    if (snapshot.getKey().equals("content")) {
                        content = snapshot.getValue(String.class);
                    } else if (snapshot.getKey().equals("image")) {
                        image = snapshot.getValue(String.class);
                    }
                }
                Picasso.get().load(Uri.parse(image)).resize(512, 0).onlyScaleDown().into(imgView);
                historyField.setText(content);
                dialog.dismiss();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }

    public void changeImage(View view) {
        if (Build.VERSION.SDK_INT < 19) {
            Intent intent = new Intent();
            intent.setType("image/*");
            intent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(Intent.createChooser(intent, getResources().getString(R.string.text3)), PICK_IMAGE_FROM_GALLERY);
        } else {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("image/*");
            startActivityForResult(Intent.createChooser(intent, getResources().getString(R.string.text3)), PICK_IMAGE_FROM_GALLERY);
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            finish();
        }
        return false;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == PICK_IMAGE_FROM_GALLERY) {
                try {
                    Picasso.get().load(data.getData()).resize(1024, 0).onlyScaleDown().into(imgView);
                    selectedImageFile = new File(getFilesDir(), "tmp_image");
                    InputStream stream = getContentResolver().openInputStream(data.getData());
                    FileOutputStream fos = new FileOutputStream(selectedImageFile);
                    int read;
                    byte[] buffer = new byte[8192];
                    while ((read = stream.read(buffer)) != -1) {
                        fos.write(buffer, 0, read);
                    }
                    fos.flush();
                    fos.close();
                    stream.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
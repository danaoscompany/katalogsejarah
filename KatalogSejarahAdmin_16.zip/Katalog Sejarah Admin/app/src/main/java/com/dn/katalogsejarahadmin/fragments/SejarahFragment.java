package com.dn.katalogsejarahadmin.fragments;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dn.katalogsejarahadmin.AddSejarahActivity;
import com.dn.katalogsejarahadmin.EditSejarahActivity;
import com.dn.katalogsejarahadmin.HomeActivity;
import com.dn.katalogsejarahadmin.R;
import com.dn.katalogsejarahadmin.Util;
import com.dn.katalogsejarahadmin.adapter.HistoryAdapter;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;

public class SejarahFragment extends Fragment {
    private final int PICK_IMAGE_FROM_GALLERY = 1;
    private final int ADD_SEJARAH = 2;
    private final int EDIT_SEJARAH = 3;
    View view;
    HomeActivity activity;
    RecyclerView historyList;
    ArrayList<JSONObject> histories;
    HistoryAdapter adapter;
    LinearLayout progress;
    FloatingActionButton add;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_sejarah, container, false);
        historyList = view.findViewById(R.id.histories);
        progress = view.findViewById(R.id.progress);
        add = view.findViewById(R.id.add);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        activity = (HomeActivity)getActivity();
        historyList.setLayoutManager(new LinearLayoutManager(activity));
        historyList.setItemAnimator(new DefaultItemAnimator());
        histories = new ArrayList<>();
        adapter = new HistoryAdapter(activity, histories, new HistoryAdapter.Listener() {

            @Override
            public void onHistoryEdited(int position, JSONObject history) {
                Intent i = new Intent(activity, EditSejarahActivity.class);
                i.putExtra("uuid", Util.getString(history, "uuid", "").trim());
                i.putExtra("sejarah_uuid", Util.getString(history, "sejarah_uuid", "").trim());
                startActivityForResult(i, EDIT_SEJARAH);
            }

            @Override
            public void onHistoryDeleted(int position, JSONObject history) {
                new AlertDialog.Builder(activity)
                        .setMessage(R.string.text28)
                        .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialogInterface, int which) {
                                final ProgressDialog dialog = activity.createDialog(R.string.text29);
                                dialog.show();
                                FirebaseDatabase.getInstance().getReference("sejarah")
                                        .child(Util.getString(history, "uuid", "").trim())
                                        .child(Util.getString(history, "sejarah_uuid", "").trim())
                                        .removeValue()
                                        .addOnSuccessListener(new OnSuccessListener<Void>() {

                                            @Override
                                            public void onSuccess(Void aVoid) {
                                                dialog.dismiss();
                                                getHistory();
                                            }
                                        });
                            }
                        })
                        .setNegativeButton(R.string.no, null)
                        .create()
                        .show();
            }
        });
        historyList.setAdapter(adapter);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(activity, AddSejarahActivity.class), ADD_SEJARAH);
            }
        });
        getHistory();
    }

    public void getHistory() {
        histories.clear();
        adapter.notifyDataSetChanged();
        progress.setVisibility(View.VISIBLE);
        FirebaseDatabase.getInstance().getReference("sejarah").orderByChild("name").equalTo("kerajaan_siak")
                .addListenerForSingleValueEvent(new ValueEventListener() {

                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.getChildrenCount() > 0) {
                            for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                String uuid = snapshot.getKey();
                                String name = "";
                                for (DataSnapshot snapshot2 : snapshot.getChildren()) {
                                    if (snapshot2.getKey().equals("name")) {
                                        name = snapshot2.getValue(String.class);
                                    }
                                }
                                if (name.equals("kerajaan_siak")) {
                                    for (DataSnapshot snapshot2 : snapshot.getChildren()) {
                                        if (!snapshot2.getKey().equals("name")) {
                                            String sejarahUUID = snapshot2.getKey();
                                            String content = "";
                                            String image = "";
                                            for (DataSnapshot snapshot3 : snapshot2.getChildren()) {
                                                if (snapshot3.getKey().equals("content")) {
                                                    content = snapshot3.getValue(String.class);
                                                } else if (snapshot3.getKey().equals("image")) {
                                                    image = snapshot3.getValue(String.class);
                                                }
                                            }
                                            try {
                                                JSONObject sejarah = new JSONObject();
                                                sejarah.put("uuid", uuid);
                                                sejarah.put("sejarah_uuid", sejarahUUID);
                                                sejarah.put("content", content);
                                                sejarah.put("image", image);
                                                histories.add(sejarah);
                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    }
                                    adapter.notifyDataSetChanged();
                                    progress.setVisibility(View.GONE);
                                }
                            }
                        } else {
                            progress.setVisibility(View.GONE);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == ADD_SEJARAH) {
                getHistory();
            } else if (requestCode == EDIT_SEJARAH) {
                getHistory();
            }
        }
    }
}

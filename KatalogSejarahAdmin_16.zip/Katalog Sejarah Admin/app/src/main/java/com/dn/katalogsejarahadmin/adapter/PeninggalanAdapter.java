package com.dn.katalogsejarahadmin.adapter;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.dn.katalogsejarahadmin.R;
import com.dn.katalogsejarahadmin.Util;
import com.squareup.picasso.Picasso;

import org.json.JSONObject;

import java.util.ArrayList;

public class PeninggalanAdapter extends RecyclerView.Adapter<PeninggalanAdapter.ViewHolder> {
    Context context;
    ArrayList<JSONObject> histories;
    Listener listener;

    public PeninggalanAdapter(Context ctx, ArrayList<JSONObject> histories, Listener listener) {
        this.context = ctx;
        this.histories = histories;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.peninggalan, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        try {
            final JSONObject peninggalan = histories.get(position);
            String image = Util.getString(peninggalan, "image", "").trim();
            if (!image.equals("")) {
                Picasso.get().load(Uri.parse(image)).resize(256, 0).onlyScaleDown().into(holder.imgView);
            } else {
                holder.imgView.setImageResource(R.drawable.img_placeholder);
            }
            holder.contentView.setText(Util.getString(peninggalan, "content", ""));
            holder.edit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        listener.onPeninggalanEdited(position, peninggalan);
                    }
                }
            });
            holder.delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        listener.onPeninggalanDeleted(position, peninggalan);
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return histories.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView imgView;
        public TextView contentView;
        public Button edit, delete;

        public ViewHolder(View view) {
            super(view);
            imgView = view.findViewById(R.id.img);
            contentView = view.findViewById(R.id.content);
            edit = view.findViewById(R.id.edit);
            delete = view.findViewById(R.id.delete);
        }
    }

    public interface Listener {

        void onPeninggalanEdited(int position, JSONObject peninggalan);
        void onPeninggalanDeleted(int position, JSONObject peninggalan);
    }
}

package com.dn.katalogsejarahadmin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.UUID;

public class AddQuizActivity extends BaseActivity {
    EditText questionField, answer1Field, answer2Field, answer3Field, answer4Field;
    Spinner correctAnswerList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_quiz);
        setTitle(R.string.add_quiz);
        setSupportActionBar((Toolbar)findViewById(R.id.toolbar));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        questionField = findViewById(R.id.question);
        answer1Field = findViewById(R.id.answer_1);
        answer2Field = findViewById(R.id.answer_2);
        answer3Field = findViewById(R.id.answer_3);
        answer4Field = findViewById(R.id.answer_4);
        correctAnswerList = findViewById(R.id.correct_answer);
        String[] correctAnswers = new String[] {
                "A", "B", "C", "D"
        };
        ArrayAdapter<String> correctAnswerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, correctAnswers);
        correctAnswerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        correctAnswerList.setAdapter(correctAnswerAdapter);
    }

    public void save(View view) {
        final String question = questionField.getText().toString().trim();
        final String answer1 = answer1Field.getText().toString().trim();
        final String answer2 = answer2Field.getText().toString().trim();
        final String answer3 = answer3Field.getText().toString().trim();
        final String answer4 = answer4Field.getText().toString().trim();
        final int correctAnswer = correctAnswerList.getSelectedItemPosition();
        if (question.equals("")) {
            show(R.string.text21);
            return;
        }
        if (answer1.equals("") || answer2.equals("") || answer3.equals("") || answer4.equals("")) {
            show(R.string.text22);
            return;
        }
        final ProgressDialog dialog = createDialog(R.string.text23);
        dialog.show();
        FirebaseDatabase.getInstance().getReference("quiz").orderByChild("name").equalTo("kerajaan_siak")
                .addListenerForSingleValueEvent(new ValueEventListener() {

                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot snapshot:dataSnapshot.getChildren()) {
                            String uuid = snapshot.getKey();
                            DatabaseReference ref = FirebaseDatabase.getInstance().getReference("quiz").child(uuid).child("questions")
                                    .child(UUID.randomUUID().toString());
                            ref.child("question").setValue(question)
                                    .addOnSuccessListener(new OnSuccessListener<Void>() {

                                        @Override
                                        public void onSuccess(Void aVoid) {
                                            DatabaseReference ref2 = ref.child("answers");
                                            ref2.child("answer_1").setValue(answer1)
                                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                        @Override
                                                        public void onSuccess(Void aVoid) {
                                                            ref2.child("answer_2").setValue(answer2)
                                                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                                        @Override
                                                                        public void onSuccess(Void aVoid) {
                                                                            ref2.child("answer_3").setValue(answer3)
                                                                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                                                        @Override
                                                                                        public void onSuccess(Void aVoid) {
                                                                                            ref2.child("answer_4").setValue(answer4)
                                                                                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                                                                        @Override
                                                                                                        public void onSuccess(Void aVoid) {
                                                                                                            ref2.child("correct").setValue(correctAnswer==0?"answer_1":correctAnswer==1?"answer_2":correctAnswer==2?"answer_3":correctAnswer==3?"answer_4":"")
                                                                                                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                                                                                        @Override
                                                                                                                        public void onSuccess(Void aVoid) {
                                                                                                                            dialog.dismiss();
                                                                                                                            setResult(Activity.RESULT_OK);
                                                                                                                            finish();
                                                                                                                        }
                                                                                                                    });
                                                                                                        }
                                                                                                    });
                                                                                        }
                                                                                    });
                                                                        }
                                                                    });
                                                        }
                                                    });
                                        }
                                    });
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            finish();
        }
        return false;
    }
}
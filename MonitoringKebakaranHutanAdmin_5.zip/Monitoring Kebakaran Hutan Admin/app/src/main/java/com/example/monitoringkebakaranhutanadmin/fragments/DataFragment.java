package com.example.monitoringkebakaranhutanadmin.fragments;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.monitoringkebakaranhutanadmin.BaseActivity;
import com.example.monitoringkebakaranhutanadmin.HomeActivity;
import com.example.monitoringkebakaranhutanadmin.R;
import com.example.monitoringkebakaranhutanadmin.Util;
import com.example.monitoringkebakaranhutanadmin.ViewDataActivity;
import com.example.monitoringkebakaranhutanadmin.adapter.DataAdapter;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class DataFragment extends Fragment {
    View view;
    HomeActivity activity;
    RecyclerView dataList;
    DataAdapter adapter;
    ArrayList<JSONObject> data;
    SwipeRefreshLayout swipe;
    LinearLayout progress;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_data, container, false);
        dataList = view.findViewById(R.id.data);
        swipe = view.findViewById(R.id.swipe);
        progress = view.findViewById(R.id.progress);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        activity = (HomeActivity)getActivity();
        dataList.setLayoutManager(new LinearLayoutManager(activity));
        dataList.setItemAnimator(new DefaultItemAnimator());
        data = new ArrayList<>();
        adapter = new DataAdapter(activity, data, new DataAdapter.Listener() {

            @Override
            public void onSelected(int position, JSONObject datum) {
                String status = Util.getString(datum, "status", "").trim();
                ArrayList<String> menus = new ArrayList<>();
                menus.add(getResources().getString(R.string.view));
                if (status.equals("terbakar")) {
                    menus.add(getResources().getString(R.string.text17));
                } else if (status.equals("proses")) {
                    menus.add(getResources().getString(R.string.text18));
                }
                menus.add(getResources().getString(R.string.delete));
                String[] menuItems = new String[menus.size()];
                for (int i=0; i<menus.size(); i++) {
                    menuItems[i] = menus.get(i);
                }
                new AlertDialog.Builder(activity)
                        .setItems(menuItems, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int position) {
                                if (position == 0) {
                                    Intent i = new Intent(activity, ViewDataActivity.class);
                                    i.putExtra("lat", Util.getDouble(datum, "lokasiKebakaranLat", 0));
                                    i.putExtra("lng", Util.getDouble(datum, "lokasiKebakaranLng", 0));
                                    startActivity(i);
                                } else if (position == 1 && (status.equals("terbakar") || status.equals("proses"))) {
                                    if (status.equals("terbakar")) {
                                        final ProgressDialog dialog = Util.createDialog(activity, R.string.text19);
                                        dialog.show();
                                        FirebaseDatabase.getInstance().getReference("Users").child(Util.getString(datum, "user_uuid", "").trim())
                                                .child("Data_Kebakaran").child(Util.getString(datum, "uuid", "").trim())
                                                .child("status").setValue("proses").addOnSuccessListener(new OnSuccessListener<Void>() {
                                            @Override
                                            public void onSuccess(Void aVoid) {
                                                FirebaseDatabase.getInstance().getReference("Users").child(Util.getString(datum, "user_uuid", "").trim())
                                                        .child("fcm_id").addListenerForSingleValueEvent(new ValueEventListener() {

                                                    @Override
                                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                        String fcmID = snapshot.getValue(String.class);
                                                        Util.sendMessage("Pembaruan data kebakaran hutan", "Klik untuk melihat data kebakaran hutan terbaru", fcmID);
                                                        dialog.dismiss();
                                                        getData();
                                                    }

                                                    @Override
                                                    public void onCancelled(@NonNull DatabaseError error) {
                                                    }
                                                });
                                            }
                                        });
                                    } else if (status.equals("proses")) {
                                        final ProgressDialog dialog = Util.createDialog(activity, R.string.text20);
                                        dialog.show();
                                        FirebaseDatabase.getInstance().getReference("Users").child(Util.getString(datum, "user_uuid", "").trim())
                                                .child("Data_Kebakaran").child(Util.getString(datum, "uuid", "").trim())
                                                .child("status").setValue("padam").addOnSuccessListener(new OnSuccessListener<Void>() {
                                            @Override
                                            public void onSuccess(Void aVoid) {
                                                FirebaseDatabase.getInstance().getReference("Users").child(Util.getString(datum, "user_uuid", "").trim())
                                                        .child("fcm_id").addListenerForSingleValueEvent(new ValueEventListener() {

                                                    @Override
                                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                        String fcmID = snapshot.getValue(String.class);
                                                        Util.sendMessage("Pembaruan data kebakaran hutan", "Klik untuk melihat data kebakaran hutan terbaru", fcmID);
                                                        dialog.dismiss();
                                                        getData();
                                                    }

                                                    @Override
                                                    public void onCancelled(@NonNull DatabaseError error) {
                                                    }
                                                });
                                            }
                                        });
                                    }
                                } else if ((position == 2 && (status.equals("terbakar") || status.equals("proses")))
                                    || (position == 1 && status.equals("padam"))) {
                                    new AlertDialog.Builder(activity)
                                            .setMessage(R.string.text15)
                                            .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {

                                                @Override
                                                public void onClick(DialogInterface dialogInterface2, int which) {
                                                    final ProgressDialog dialog = activity.createDialog(R.string.deleting_data);
                                                    dialog.show();
                                                    FirebaseDatabase.getInstance().getReference("Users")
                                                            .child(Util.getString(datum, "user_uuid", "").trim())
                                                            .child("Data_Kebakaran")
                                                            .child(Util.getString(datum, "uuid", "").trim())
                                                            .removeValue()
                                                            .addOnSuccessListener(new OnSuccessListener<Void>() {

                                                                @Override
                                                                public void onSuccess(Void aVoid) {
                                                                    dialog.dismiss();
                                                                    getData();
                                                                }
                                                            });
                                                }
                                            })
                                            .setNegativeButton(R.string.no, null)
                                            .create()
                                            .show();
                                }
                            }
                        })
                        .create()
                        .show();
            }
        });
        dataList.setAdapter(adapter);
        swipe.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {

            @Override
            public void onRefresh() {
                getData();
            }
        });
        getData();
    }

    public void getData() {
        progress.setVisibility(View.VISIBLE);
        data.clear();
        adapter.notifyDataSetChanged();
        FirebaseDatabase.getInstance().getReference("Users")
                .addListenerForSingleValueEvent(new ValueEventListener() {

                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot snapshot:dataSnapshot.getChildren()) {
                            String userUuid = snapshot.getKey();
                            String name = "";
                            for (DataSnapshot snapshot2:snapshot.getChildren()) {
                                if (snapshot2.getKey().equals("fullname")) {
                                    name = snapshot2.getValue(String.class);
                                }
                            }
                            for (DataSnapshot snapshot2:snapshot.getChildren()) {
                                if (snapshot2.getKey().equals("Data_Kebakaran")) {
                                    for (DataSnapshot snapshot4:snapshot2.getChildren()) {
                                        String uuid = snapshot4.getKey();
                                        String date = "";
                                        String jam = "";
                                        String lokasiKebakaran = "";
                                        double lokasiKebakaranLat = 0;
                                        double lokasiKebakaranLng = 0;
                                        String noTelp = "";
                                        String penyebabKebakaran = "";
                                        String status = "";
                                        JSONObject datum = new JSONObject();
                                        for (DataSnapshot snapshot5:snapshot4.getChildren()) {
                                            if (snapshot5.getKey().equals("date")) {
                                                date = snapshot5.getValue(String.class);
                                            } else if (snapshot5.getKey().equals("jam")) {
                                                jam = snapshot5.getValue(String.class);
                                            } else if (snapshot5.getKey().equals("lokasiKebakaran")) {
                                                lokasiKebakaran = snapshot5.getValue(String.class);
                                            } else if (snapshot5.getKey().equals("lokasiKebakaranLat")) {
                                                lokasiKebakaranLat = snapshot5.getValue(Double.class);
                                            } else if (snapshot5.getKey().equals("lokasiKebakaranLng")) {
                                                lokasiKebakaranLng = snapshot5.getValue(Double.class);
                                            } else if (snapshot5.getKey().equals("notelp")) {
                                                noTelp = snapshot5.getValue(String.class);
                                            } else if (snapshot5.getKey().equals("penyebabKebakaran")) {
                                                penyebabKebakaran = snapshot5.getValue(String.class);
                                            } else if (snapshot5.getKey().equals("status")) {
                                                status = snapshot5.getValue(String.class);
                                            }
                                        }
                                        try {
                                            datum.put("uuid", uuid);
                                            datum.put("user_uuid", userUuid);
                                            datum.put("user_name", name);
                                            datum.put("date", date);
                                            datum.put("jam", jam);
                                            datum.put("lokasiKebakaran", lokasiKebakaran);
                                            datum.put("lokasiKebakaranLat", lokasiKebakaranLat);
                                            datum.put("lokasiKebakaranLng", lokasiKebakaranLng);
                                            datum.put("noTelp", noTelp);
                                            datum.put("penyebabKebakaran", penyebabKebakaran);
                                            datum.put("status", status);
                                            data.add(datum);
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    }
                                }
                            }
                        }
                        Collections.sort(data, new Comparator<JSONObject>() {

                            @Override
                            public int compare(JSONObject datum1, JSONObject datum2) {
                                try {
                                    long time1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(Util.getString(datum1, "date", "").trim()).getTime();
                                    long time2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(Util.getString(datum2, "date", "").trim()).getTime();
                                    if (time1 > time2) {
                                        return -1;
                                    } else if (time1 < time2) {
                                        return 1;
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                return 0;
                            }
                        });
                        progress.setVisibility(View.GONE);
                        adapter.notifyDataSetChanged();
                        swipe.setRefreshing(false);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
    }
}

package com.example.monitoringkebakaranhutanadmin;

import androidx.multidex.MultiDexApplication;

public class MyApplication extends MultiDexApplication {
}

package com.example.monitoringkebakaranhutanadmin;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;

import com.example.monitoringkebakaranhutanadmin.fragments.DataFragment;
import com.example.monitoringkebakaranhutanadmin.fragments.InfoFragment;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.messaging.FirebaseMessaging;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.core.view.GravityCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class HomeActivity extends BaseActivity {
    DataFragment dataFragment;
    InfoFragment infoFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setItemIconTintList(null);
        dataFragment = new DataFragment();
        infoFragment = new InfoFragment();
        FirebaseMessaging.getInstance().subscribeToTopic("admin");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager mgr = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            NotificationChannel channel = new NotificationChannel(getPackageName()+".NOTIFICATIONS",
                    "Monitoring Kebakaran Hutan Admin notifications", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Manage notifications for Monitoring Kebakaran Hutan Admin");
            mgr.createNotificationChannel(channel);
        }
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {
                drawer.closeDrawer((int)GravityCompat.START);
                int id = menuItem.getItemId();
                if (id == R.id.nav_data) {
                    selectFragment(dataFragment);
                } else if (id == R.id.nav_info) {
                    selectFragment(infoFragment);
                } else if (id == R.id.nav_logout) {
                    new AlertDialog.Builder(HomeActivity.this)
                            .setMessage(R.string.text16)
                            .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    write("email", "");
                                    write("password", "");
                                    startActivity(new Intent(HomeActivity.this, MainActivity.class));
                                    finish();
                                }
                            })
                            .setNegativeButton(R.string.no, null)
                            .create()
                            .show();
                }
                return false;
            }
        });
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.open_drawer, R.string.close_drawer) {
            public void onDrawerClosed(View view) {
                super.onDrawerClosed(view);
            }

            public void onDrawerOpened(View view) {
                super.onDrawerOpened(view);
            }
        };
        drawer.setDrawerListener(toggle);
        toggle.syncState();
        selectFragment(dataFragment);
    }

    public void selectFragment(Fragment fr) {
        if (fr instanceof DataFragment) {
            setTitle(R.string.menu_data);
        } else if (fr instanceof InfoFragment) {
            setTitle(R.string.menu_info);
        }
        getSupportFragmentManager().beginTransaction().replace(R.id.content_main, fr).commit();
    }
}

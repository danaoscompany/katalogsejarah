package com.prod.smartcity;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.util.Base64;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.loader.content.CursorLoader;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.NoSuchAlgorithmException;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

import org.json.JSONObject;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;

public class Util {

    public static void show(final Context ctx, final String message) {
        runLater(new Runnable() {

            @Override
            public void run() {
                Toast.makeText(ctx, message, Toast.LENGTH_LONG).show();
            }
        });
    }

    public static void log(String message) {
        //Log.e(Build.MODEL, message);
    }

    public static String getString(JSONObject obj, String name, String defaultValue) {
        try {
            String value = obj.getString(name);
            if (value == null || value.equals("null") || value.equals("NULL")) {
                return defaultValue;
            } else {
                return value;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return defaultValue;
    }

    public static int getInt(JSONObject obj, String name, int defaultValue) {
        try {
            String value = obj.getString(name);
            if (value == null || value.equals("null") || value.equals("NULL")) {
                return defaultValue;
            } else {
                return Integer.parseInt(value);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return defaultValue;
    }

    public static double getDouble(JSONObject obj, String name, double defaultValue) {
        try {
            String value = obj.getString(name);
            if (value == null || value.equals("null") || value.equals("NULL")) {
                return defaultValue;
            } else {
                return Double.parseDouble(value);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return defaultValue;
    }

    public static String read(Context ctx, String name, String defaultValue) {
        SharedPreferences sp = ctx.getSharedPreferences("data", Context.MODE_PRIVATE);
        return sp.getString(name, defaultValue);
    }

    public static String readEncrypted(Context ctx, String name, String defaultValue) {
        SharedPreferences sp = ctx.getSharedPreferences("data", Context.MODE_PRIVATE);
        String value = sp.getString(encrypt(name), "");
        if (value == null || value.trim().equals("")) {
            return defaultValue;
        }
        try {
            return new String(Base64.decode(value, Base64.DEFAULT));
        } catch (Exception e) {
        }
        return defaultValue;
    }

    public static int read(Context ctx, String name, int defaultValue) {
        SharedPreferences sp = ctx.getSharedPreferences("data", Context.MODE_PRIVATE);
        return sp.getInt(name, defaultValue);
    }

    public static int readEncrypted(Context ctx, String name, int defaultValue) {
        SharedPreferences sp = ctx.getSharedPreferences("data", Context.MODE_PRIVATE);
        String value = sp.getString(encrypt(name), "");
        if (value == null || value.trim().equals("")) {
            return defaultValue;
        }
        try {
            return Integer.parseInt(new String(Base64.decode(value, Base64.DEFAULT)));
        } catch (Exception e) {
        }
        return defaultValue;
    }

    public static boolean read(Context ctx, String name, boolean defaultValue) {
        SharedPreferences sp = ctx.getSharedPreferences("data", Context.MODE_PRIVATE);
        return sp.getBoolean(name, defaultValue);
    }

    public static boolean readEncrypted(Context ctx, String name, boolean defaultValue) {
        SharedPreferences sp = ctx.getSharedPreferences("data", Context.MODE_PRIVATE);
        String value = sp.getString(encrypt(name), "");
        if (value == null || value.trim().equals("")) {
            return defaultValue;
        }
        try {
            return Boolean.parseBoolean(new String(Base64.decode(value, Base64.DEFAULT)));
        } catch (Exception e) {
        }
        return defaultValue;
    }

    public static void write(Context ctx, String name, String value) {
        SharedPreferences sp = ctx.getSharedPreferences("data", Context.MODE_PRIVATE);
        SharedPreferences.Editor e = sp.edit();
        e.putString(name, value);
        e.commit();
    }

    public static void writeEncrypted(Context ctx, String name, String value) {
        SharedPreferences sp = ctx.getSharedPreferences("data", Context.MODE_PRIVATE);
        SharedPreferences.Editor e = sp.edit();
        try {
            e.putString(encrypt(name), encrypt(value));
        } catch (Exception exception) {
        }
        e.commit();
    }

    public static String encrypt(String value) {
        try {
            return Base64.encodeToString(value.getBytes(), Base64.DEFAULT);
        } catch (Exception e) {
        }
        return "";
    }

    public static void write(Context ctx, String name, int value) {
        SharedPreferences sp = ctx.getSharedPreferences("data", Context.MODE_PRIVATE);
        SharedPreferences.Editor e = sp.edit();
        e.putInt(name, value);
        e.commit();
    }

    public static void writeEncrypted(Context ctx, String name, int value) {
        SharedPreferences sp = ctx.getSharedPreferences("data", Context.MODE_PRIVATE);
        SharedPreferences.Editor e = sp.edit();
        e.putString(encrypt(name), Base64.encodeToString(("" + value).getBytes(), Base64.DEFAULT));
        e.commit();
    }

    public static void write(Context ctx, String name, boolean value) {
        SharedPreferences sp = ctx.getSharedPreferences("data", Context.MODE_PRIVATE);
        SharedPreferences.Editor e = sp.edit();
        e.putBoolean(name, value);
        e.commit();
    }

    public static void writeEncrypted(Context ctx, String name, boolean value) {
        SharedPreferences sp = ctx.getSharedPreferences("data", Context.MODE_PRIVATE);
        SharedPreferences.Editor e = sp.edit();
        e.putString(encrypt(name), Base64.encodeToString(("" + value).getBytes(), Base64.DEFAULT));
        e.commit();
    }

    public static void run(Runnable runnable) {
        new Thread(runnable).start();
    }

    public static void runLater(Runnable runnable) {
        new Handler(Looper.getMainLooper()).post(runnable);
    }

    public static OkHttpClient getOkHttpClient() {
        OkHttpClient client = new OkHttpClient.Builder()
                .readTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .connectTimeout(60, TimeUnit.SECONDS)
                .build();
        return client;
    }

    public static void get(final Context ctx, final Listener listener, final String url) {
        run(new Runnable() {

            public void run() {
                try {
                    OkHttpClient client = getOkHttpClient();
                    Request request = new Request.Builder()
                            .url(url)
                            .addHeader("Authorization", "Bearer "+Constants.ACCESS_TOKEN)
                            .build();
                    final String response = client.newCall(request).execute().body().string();
                    runLater(new Runnable() {

                        public void run() {
                            if (listener != null) {
                                listener.onResponse(response);
                            }
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public static void post(final Context ctx, final Listener listener, final String url, final String... params) {
        run(new Runnable() {

            public void run() {
                try {
                    OkHttpClient client = getOkHttpClient();
                    MultipartBody.Builder builder = new MultipartBody.Builder()
                            .setType(MultipartBody.FORM);
                    for (int i = 0; i < params.length; ) {
                        if (params[i].equals("file")) {
                            String fileName = params[i + 1];
                            String mimeType = params[i + 2];
                            String filePath = params[i + 3];
                            builder.addFormDataPart("file", fileName,
                                    RequestBody.create(MediaType.parse(mimeType), new File(filePath)));
                            i += 4;
                        } else {
                            builder.addFormDataPart(params[i], params[i + 1]);
                            i += 2;
                        }
                    }
                    Request request = new Request.Builder()
                            .url(url)
                            .addHeader("Authorization", "Bearer "+Constants.ACCESS_TOKEN)
                            .post(builder.build())
                            .build();
                    final String response = client.newCall(request).execute().body().string();
                    runLater(new Runnable() {

                        public void run() {
                            if (listener != null) {
                                listener.onResponse(response);
                            }
                        }
                    });
                } catch (final Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public interface Listener {

        void onResponse(String response);
    }

    public static ProgressDialog createDialog(Context ctx, String message) {
        ProgressDialog dialog = new ProgressDialog(ctx);
        dialog.setCancelable(false);
        dialog.setMessage(message);
        return dialog;
    }

    public static ProgressDialog createDialog(Context ctx, int messageID) {
        ProgressDialog dialog = new ProgressDialog(ctx);
        dialog.setCancelable(false);
        dialog.setMessage(ctx.getResources().getString(messageID));
        return dialog;
    }

    public static void dismissDialog(final ProgressDialog dialog) {
        runLater(new Runnable() {

            @Override
            public void run() {
                if (dialog.isShowing()) {
                    dialog.dismiss();
                }
            }
        });
    }

    public static String formatPhoneNumber(String number) {
        number = number.replaceAll("[^0-9]+", "");
        return number;
    }

    public static String formatPrice(String price) {
        price = price.replaceAll("[^0-9]+", "");
        return "Rp " + new DecimalFormat("#,###").format(Integer.parseInt(price)) + ",00";
    }

    public static String removeNonDigitValues(String price) {
        return price.replaceAll("[^0-9]+", "");
    }

    public static boolean isPackageInstalled(PackageManager packageManager, String packageName) {
        try {
            packageManager.getPackageInfo(packageName, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    public static int getRadioButtonIndex(RadioGroup checkBoxGroup) {
        return checkBoxGroup.indexOfChild(checkBoxGroup.findViewById(checkBoxGroup.getCheckedRadioButtonId()));
    }

    public static File createImageFile(Context ctx) {
        try {
            String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            String imageFileName = "JPEG_" + timeStamp + "_";
            File storageDir = ctx.getExternalFilesDir(Environment.DIRECTORY_PICTURES);
            File image = File.createTempFile(
                    imageFileName,  /* prefix */
                    ".jpg",         /* suffix */
                    storageDir      /* directory */
            );
            return image;
        } catch (Exception e) {
        }
        return null;
    }

    public static Bitmap getCroppedBitmap(Bitmap bitmap) {
        Bitmap output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getWidth(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);
        final int color = 0xff424242;
        final Paint paint = new Paint();
        final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getWidth());
        paint.setAntiAlias(true);
        canvas.drawARGB(0, 0, 0, 0);
        paint.setColor(color);
        // canvas.drawRoundRect(rectF, roundPx, roundPx, paint);
        canvas.drawCircle(bitmap.getWidth() / 2, bitmap.getWidth() / 2, bitmap.getWidth() / 2, paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint);
        //Bitmap _bmp = Bitmap.createScaledBitmap(output, 60, 60, false);
        //return _bmp;
        return output;
    }

    public static Bitmap textToBitmap(String text, float textSize, int textColor) {
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setTextSize(textSize);
        paint.setColor(textColor);
        paint.setTextAlign(Paint.Align.LEFT);
        float baseline = -paint.ascent(); // ascent() is negative
        int width = (int) (paint.measureText(text) + 0.0f); // round
        int height = (int) (baseline + paint.descent() + 0.0f);
        Bitmap image = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(image);
        canvas.drawText(text, 0, baseline, paint);
        return image;
    }

    public static void showLog(Context ctx, String message) {
        Intent sendIntent = new Intent(Intent.ACTION_VIEW);
        sendIntent.setData(Uri.parse("sms:"));
        sendIntent.putExtra("sms_body", message);
        ctx.startActivity(sendIntent);
    }

    public static String getExtension(String path) {
        return path.substring(path.lastIndexOf("."), path.length());
    }

    public static String getMediaType(Context ctx, Uri uri) {
        return ctx.getContentResolver().getType(uri);
    }

    public static String getRealPath(Context context, Uri fileUri) {
        String realPath;
        if (Build.VERSION.SDK_INT < 11) {
            realPath = getRealPathFromURI_BelowAPI11(context, fileUri);
        } else if (Build.VERSION.SDK_INT < 19) {
            realPath = getRealPathFromURI_API11to18(context, fileUri);
        } else {
            realPath = getRealPathFromURI_API19(context, fileUri);
        }
        return realPath;
    }

    public static String getRealPathFromURI_BelowAPI11(Context context, Uri contentUri) {
        String[] proj = {MediaStore.Images.Media.DATA};
        Cursor cursor = context.getContentResolver().query(contentUri, proj, null, null, null);
        int column_index = 0;
        String result = "";
        if (cursor != null) {
            column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            result = cursor.getString(column_index);
            cursor.close();
            return result;
        }
        return result;
    }

    @SuppressLint("NewApi")
    public static String getRealPathFromURI_API11to18(Context context, Uri contentUri) {
        String[] proj = {MediaStore.Images.Media.DATA};
        String result = null;
        CursorLoader cursorLoader = new CursorLoader(context, contentUri, proj, null, null, null);
        Cursor cursor = cursorLoader.loadInBackground();
        if (cursor != null) {
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            result = cursor.getString(column_index);
            cursor.close();
        }
        return result;
    }

    @SuppressLint("NewApi")
    public static String getRealPathFromURI_API19(final Context context, final Uri uri) {

        final boolean isKitKat = Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT;

        // DocumentProvider
        if (isKitKat && DocumentsContract.isDocumentUri(context, uri)) {
            // ExternalStorageProvider
            if (isExternalStorageDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                if ("primary".equalsIgnoreCase(type)) {
                    return Environment.getExternalStorageDirectory() + "/" + split[1];
                }

                // TODO handle non-primary volumes
            }
            // DownloadsProvider
            else if (isDownloadsDocument(uri)) {

                final String id = DocumentsContract.getDocumentId(uri);
                final Uri contentUri = ContentUris.withAppendedId(
                        Uri.parse("content://downloads/public_downloads"), Long.valueOf(id));

                return getDataColumn(context, contentUri, null, null);
            }
            // MediaProvider
            else if (isMediaDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                Uri contentUri = null;
                if ("image".equals(type)) {
                    contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals(type)) {
                    contentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else if ("audio".equals(type)) {
                    contentUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                }

                final String selection = "_id=?";
                final String[] selectionArgs = new String[]{
                        split[1]
                };

                return getDataColumn(context, contentUri, selection, selectionArgs);
            }
        }
        // MediaStore (and general)
        else if ("content".equalsIgnoreCase(uri.getScheme())) {

            // Return the remote address
            if (isGooglePhotosUri(uri))
                return uri.getLastPathSegment();

            return getDataColumn(context, uri, null, null);
        }
        // File
        else if ("file".equalsIgnoreCase(uri.getScheme())) {
            return uri.getPath();
        }

        return null;
    }

    public static String getDataColumn(Context context, Uri uri, String selection,
                                       String[] selectionArgs) {

        Cursor cursor = null;
        final String column = "_data";
        final String[] projection = {
                column
        };

        try {
            cursor = context.getContentResolver().query(uri, projection, selection, selectionArgs,
                    null);
            if (cursor != null && cursor.moveToFirst()) {
                final int index = cursor.getColumnIndexOrThrow(column);
                return cursor.getString(index);
            }
        } finally {
            if (cursor != null)
                cursor.close();
        }
        return null;
    }

    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }

    public static boolean isGooglePhotosUri(Uri uri) {
        return "com.google.android.apps.photos.content".equals(uri.getAuthority());
    }

    private static boolean newLocationReceived = false;

    @SuppressLint("MissingPermission")
    public static void getLocation(Context ctx, final LocationUpdateListener listener) {
        newLocationReceived = false;
        try {
            LocationManager mgr = (LocationManager) ctx.getSystemService(Context.LOCATION_SERVICE);
            Location location = mgr.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (location == null) {
                location = mgr.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            }
            if (location == null) {
                mgr.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, new LocationListener() {

                    @Override
                    public void onLocationChanged(Location location) {
                        // TODO: Implement this method
                        if (newLocationReceived) return;
                        newLocationReceived = true;
                        if (location != null && listener != null) {
                            listener.onLocationUpdate(location.getLatitude(), location.getLongitude());
                        }
                    }

                    @Override
                    public void onStatusChanged(String p1, int p2, Bundle p3) {
                        // TODO: Implement this method
                    }

                    @Override
                    public void onProviderEnabled(String p1) {
                        // TODO: Implement this method
                    }

                    @Override
                    public void onProviderDisabled(String p1) {
                        // TODO: Implement this method
                    }
                });
                mgr.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, new LocationListener() {

                    @Override
                    public void onLocationChanged(Location location) {
                        // TODO: Implement this method
                        if (newLocationReceived) return;
                        newLocationReceived = true;
                        if (location != null && listener != null) {
                            listener.onLocationUpdate(location.getLatitude(), location.getLongitude());
                        }
                    }

                    @Override
                    public void onStatusChanged(String p1, int p2, Bundle p3) {
                        // TODO: Implement this method
                    }

                    @Override
                    public void onProviderEnabled(String p1) {
                        // TODO: Implement this method
                    }

                    @Override
                    public void onProviderDisabled(String p1) {
                        // TODO: Implement this method
                    }
                });
            } else {
                if (newLocationReceived) return;
                newLocationReceived = true;
                if (location != null && listener != null) {
                    listener.onLocationUpdate(location.getLatitude(), location.getLongitude());
                }
            }
        } catch (Exception e) {
        }
    }

    public interface LocationUpdateListener {

        void onLocationUpdate(double lat, double lng);
    }

    public static String generateHashWithHmac256(String message, String key) {
        try {
            final String hashingAlgorithm = "HmacSHA256"; //or "HmacSHA1", "HmacSHA512"
            byte[] bytes = hmac(hashingAlgorithm, key.getBytes(), message.getBytes());
            final String messageDigest = bytesToHex(bytes);
            return messageDigest;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    public static byte[] hmac(String algorithm, byte[] key, byte[] message) throws NoSuchAlgorithmException, InvalidKeyException {
        Mac mac = Mac.getInstance(algorithm);
        mac.init(new SecretKeySpec(key, algorithm));
        return mac.doFinal(message);
    }

    public static String bytesToHex(byte[] bytes) {
        final char[] hexArray = "0123456789abcdef".toCharArray();
        char[] hexChars = new char[bytes.length * 2];
        for (int j = 0, v; j < bytes.length; j++) {
            v = bytes[j] & 0xFF;
            hexChars[j * 2] = hexArray[v >>> 4];
            hexChars[j * 2 + 1] = hexArray[v & 0x0F];
        }
        return new String(hexChars);
    }
    
    public static String encodeHmacSHA256(String key, String data) throws Exception {
        Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
        SecretKeySpec secretKey = new SecretKeySpec(data.getBytes(), "HmacSHA256");
        sha256_HMAC.init(secretKey);
        String hash = Base64.encodeToString(sha256_HMAC.doFinal(key.getBytes()), Base64.NO_WRAP);
        return hash;
	}
}

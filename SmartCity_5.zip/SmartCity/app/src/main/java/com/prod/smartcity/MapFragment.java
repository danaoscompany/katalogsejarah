package com.prod.smartcity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.firebase.geofire.GeoFire;
import com.firebase.geofire.GeoLocation;
import com.firebase.geofire.GeoQuery;
import com.firebase.geofire.GeoQueryEventListener;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONArray;
import org.json.JSONObject;

public class MapFragment extends Fragment {
    View view;
    HomeActivity activity;
    GoogleMap map;
    String category = "";
    double latitude = 0;
    double longitude = 0;

    public MapFragment(String category) {
        this.category = category;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_map, container, false);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        activity = (HomeActivity)getActivity();
        SupportMapFragment mf = (SupportMapFragment)getChildFragmentManager().findFragmentById(R.id.mf);
        mf.getMapAsync(new OnMapReadyCallback() {

            @Override
            public void onMapReady(GoogleMap googleMap) {
                map = googleMap;
                Util.getLocation(activity, new Util.LocationUpdateListener() {

                    @Override
                    public void onLocationUpdate(double lat, double lng) {
                        map.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(lat, lng), 15.0f));
                    }
                });
                map.setOnMapClickListener(new GoogleMap.OnMapClickListener() {

                    @Override
                    public void onMapClick(LatLng latLng) {
                        latitude = latLng.latitude;
                        longitude = latLng.longitude;
                        getManualLocations(latitude, longitude);
                        map.clear();
                        map.addMarker(new MarkerOptions().position(latLng)
                                .icon(BitmapDescriptorFactory.defaultMarker()));
                        map.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15.0f));
                        if (category.equals("all") || category.equals("hotel")) {
                            activity.get(new BaseActivity.Listener() {

                                @Override
                                public void onResponse(String response) {
                                    try {
                                        JSONArray items = new JSONObject(response).getJSONObject("results").getJSONArray("items");
                                        for (int i = 0; i < items.length(); i++) {
                                            JSONObject item = items.getJSONObject(i);
                                            double latitude = item.getJSONArray("position").getDouble(0);
                                            double longitude = item.getJSONArray("position").getDouble(1);
                                            map.addMarker(new MarkerOptions().position(new LatLng(latitude, longitude))
                                                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.hotel_marker))
                                                    .title(Util.getString(item, "title", "").trim()));
                                        }
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            }, "https://places.ls.hereapi.com/places/v1/discover/explore?in=" + latitude + "," + longitude + ";r=15000&cat=hotel");
                        }
                        if (category.equals("all") || category.equals("bank")) {
                            activity.get(new BaseActivity.Listener() {

                                @Override
                                public void onResponse(String response) {
                                    try {
                                        JSONArray items = new JSONObject(response).getJSONObject("results").getJSONArray("items");
                                        for (int i = 0; i < items.length(); i++) {
                                            JSONObject item = items.getJSONObject(i);
                                            String title = Util.getString(item, "title", "").trim();
                                            if (!title.toLowerCase().startsWith("atm")) {
                                                double latitude = item.getJSONArray("position").getDouble(0);
                                                double longitude = item.getJSONArray("position").getDouble(1);
                                                map.addMarker(new MarkerOptions().position(new LatLng(latitude, longitude))
                                                        .icon(BitmapDescriptorFactory.fromResource(R.drawable.bank_marker))
                                                        .title(title));
                                            }
                                        }
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            }, "https://places.ls.hereapi.com/places/v1/discover/explore?in=" + latitude + "," + longitude + ";r=15000&cat=atm-bank-exchange");
                        }
                        if (category.equals("all") || category.equals("atm")) {
                            activity.get(new BaseActivity.Listener() {

                                @Override
                                public void onResponse(String response) {
                                    try {
                                        JSONArray items = new JSONObject(response).getJSONObject("results").getJSONArray("items");
                                        for (int i = 0; i < items.length(); i++) {
                                            JSONObject item = items.getJSONObject(i);
                                            String title = Util.getString(item, "title", "").trim();
                                            if (title.toLowerCase().startsWith("atm")) {
                                                double latitude = item.getJSONArray("position").getDouble(0);
                                                double longitude = item.getJSONArray("position").getDouble(1);
                                                map.addMarker(new MarkerOptions().position(new LatLng(latitude, longitude))
                                                        .icon(BitmapDescriptorFactory.fromResource(R.drawable.atm_marker))
                                                        .title(title));
                                            }
                                        }
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            }, "https://places.ls.hereapi.com/places/v1/discover/explore?in=" + latitude + "," + longitude + ";r=15000&cat=atm-bank-exchange");
                        }
                        if (category.equals("all") || category.equals("restaurant")) {
                            activity.get(new BaseActivity.Listener() {

                                @Override
                                public void onResponse(String response) {
                                    try {
                                        JSONArray items = new JSONObject(response).getJSONObject("results").getJSONArray("items");
                                        for (int i = 0; i < items.length(); i++) {
                                            JSONObject item = items.getJSONObject(i);
                                            double latitude = item.getJSONArray("position").getDouble(0);
                                            double longitude = item.getJSONArray("position").getDouble(1);
                                            map.addMarker(new MarkerOptions().position(new LatLng(latitude, longitude))
                                                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.restaurant_marker))
                                                    .title(Util.getString(item, "title", "").trim()));
                                        }
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            }, "https://places.ls.hereapi.com/places/v1/discover/explore?in=" + latitude + "," + longitude + ";r=15000&cat=eat-drink");
                        }
                        if (category.equals("all") || category.equals("gas_station")) {
                            activity.get(new BaseActivity.Listener() {

                                @Override
                                public void onResponse(String response) {
                                    try {
                                        JSONArray items = new JSONObject(response).getJSONObject("results").getJSONArray("items");
                                        for (int i = 0; i < items.length(); i++) {
                                            JSONObject item = items.getJSONObject(i);
                                            double latitude = item.getJSONArray("position").getDouble(0);
                                            double longitude = item.getJSONArray("position").getDouble(1);
                                            map.addMarker(new MarkerOptions().position(new LatLng(latitude, longitude))
                                                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.gas_station_marker))
                                                    .title(Util.getString(item, "title", "").trim()));
                                        }
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            }, "https://places.ls.hereapi.com/places/v1/discover/explore?in=" + latitude + "," + longitude + ";r=15000&cat=petrol-station");
                        }
                        if (category.equals("all") || category.equals("hospital")) {
                            activity.get(new BaseActivity.Listener() {

                                @Override
                                public void onResponse(String response) {
                                    try {
                                        JSONArray items = new JSONObject(response).getJSONObject("results").getJSONArray("items");
                                        for (int i = 0; i < items.length(); i++) {
                                            JSONObject item = items.getJSONObject(i);
                                            double latitude = item.getJSONArray("position").getDouble(0);
                                            double longitude = item.getJSONArray("position").getDouble(1);
                                            map.addMarker(new MarkerOptions().position(new LatLng(latitude, longitude))
                                                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.hospital_marker))
                                                    .title(Util.getString(item, "title", "").trim()));
                                        }
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            }, "https://places.ls.hereapi.com/places/v1/discover/explore?in=" + latitude + "," + longitude + ";r=15000&cat=hospital-health-care-facility");
                        }
                        if (category.equals("all") || category.equals("school")) {
                            activity.get(new BaseActivity.Listener() {

                                @Override
                                public void onResponse(String response) {
                                    try {
                                        JSONArray items = new JSONObject(response).getJSONObject("results").getJSONArray("items");
                                        for (int i = 0; i < items.length(); i++) {
                                            JSONObject item = items.getJSONObject(i);
                                            double latitude = item.getJSONArray("position").getDouble(0);
                                            double longitude = item.getJSONArray("position").getDouble(1);
                                            map.addMarker(new MarkerOptions().position(new LatLng(latitude, longitude))
                                                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.school_marker))
                                                    .title(Util.getString(item, "title", "").trim()));
                                        }
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            }, "https://places.ls.hereapi.com/places/v1/discover/explore?in=" + latitude + "," + longitude + ";r=15000&cat=education-facility,higher-education,school,training-and-development,coaching-institute,fine-arts,language-studies");
                        }
                        if (category.equals("all") || category.equals("office")) {
                            activity.get(new BaseActivity.Listener() {

                                @Override
                                public void onResponse(String response) {
                                    try {
                                        JSONArray items = new JSONObject(response).getJSONObject("results").getJSONArray("items");
                                        for (int i = 0; i < items.length(); i++) {
                                            JSONObject item = items.getJSONObject(i);
                                            double latitude = item.getJSONArray("position").getDouble(0);
                                            double longitude = item.getJSONArray("position").getDouble(1);
                                            map.addMarker(new MarkerOptions().position(new LatLng(latitude, longitude))
                                                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.office_marker))
                                                    .title(Util.getString(item, "title", "").trim()));
                                        }
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            }, "https://places.ls.hereapi.com/places/v1/discover/explore?in=" + latitude + "," + longitude + ";r=15000&cat=administrative-areas-buildings");
                        }
                        if (category.equals("all") || category.equals("worship_place")) {
                            activity.get(new BaseActivity.Listener() {

                                @Override
                                public void onResponse(String response) {
                                    try {
                                        JSONArray items = new JSONObject(response).getJSONObject("results").getJSONArray("items");
                                        for (int i = 0; i < items.length(); i++) {
                                            JSONObject item = items.getJSONObject(i);
                                            double latitude = item.getJSONArray("position").getDouble(0);
                                            double longitude = item.getJSONArray("position").getDouble(1);
                                            map.addMarker(new MarkerOptions().position(new LatLng(latitude, longitude))
                                                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.worship_place_marker))
                                                    .title(Util.getString(item, "title", "").trim()));
                                        }
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            }, "https://places.ls.hereapi.com/places/v1/discover/explore?in=" + latitude + "," + longitude + ";r=15000&cat=religious-place");
                        }
                    }
                });
            }
        });
    }

    public void getManualLocations(double latitude, double longitude) {
        GeoQuery query = new GeoFire(FirebaseDatabase.getInstance(Constants.FIREBASE_DATABASE_URL)
                .getReference("locations"))
                .queryAtLocation(new GeoLocation(latitude, longitude), 15000);
        query.addGeoQueryEventListener(new GeoQueryEventListener() {

            @Override
            public void onKeyEntered(String key, GeoLocation location) {
                FirebaseDatabase.getInstance(Constants.FIREBASE_DATABASE_URL).getReference("locations").child(key)
                        .addListenerForSingleValueEvent(new ValueEventListener() {

                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                String name = "";
                                String category = "";
                                double latitude = 0;
                                double longitude = 0;
                                for (DataSnapshot snapshot:dataSnapshot.getChildren()) {
                                    if (snapshot.getKey().equals("name")) {
                                        name = snapshot.getValue(String.class);
                                    } else if (snapshot.getKey().equals("category")) {
                                        category = snapshot.getValue(String.class);
                                    } else if (snapshot.getKey().equals("latitude")) {
                                        latitude = snapshot.getValue(Double.class);
                                    } else if (snapshot.getKey().equals("longitude")) {
                                        longitude = snapshot.getValue(Double.class);
                                    }
                                }
                                if (category.equals("all") || category.equals(MapFragment.this.category)) {
                                    map.addMarker(new MarkerOptions().position(new LatLng(latitude, longitude))
                                            .icon(BitmapDescriptorFactory.fromResource(R.drawable.hotel_marker))
                                            .title(name));
                                }
                                if (category.equals("all") || category.equals(MapFragment.this.category)) {
                                    map.addMarker(new MarkerOptions().position(new LatLng(latitude, longitude))
                                            .icon(BitmapDescriptorFactory.fromResource(R.drawable.bank_marker))
                                            .title(name));
                                }
                                if (category.equals("all") || category.equals(MapFragment.this.category)) {
                                    map.addMarker(new MarkerOptions().position(new LatLng(latitude, longitude))
                                            .icon(BitmapDescriptorFactory.fromResource(R.drawable.atm_marker))
                                            .title(name));
                                }
                                if (category.equals("all") || category.equals(MapFragment.this.category)) {
                                    map.addMarker(new MarkerOptions().position(new LatLng(latitude, longitude))
                                            .icon(BitmapDescriptorFactory.fromResource(R.drawable.restaurant_marker))
                                            .title(name));
                                }
                                if (category.equals("all") || category.equals(MapFragment.this.category)) {
                                    map.addMarker(new MarkerOptions().position(new LatLng(latitude, longitude))
                                            .icon(BitmapDescriptorFactory.fromResource(R.drawable.gas_station_marker))
                                            .title(name));
                                }
                                if (category.equals("all") || category.equals(MapFragment.this.category)) {
                                    map.addMarker(new MarkerOptions().position(new LatLng(latitude, longitude))
                                            .icon(BitmapDescriptorFactory.fromResource(R.drawable.hospital_marker))
                                            .title(name));
                                }
                                if (category.equals("all") || category.equals(MapFragment.this.category)) {
                                    map.addMarker(new MarkerOptions().position(new LatLng(latitude, longitude))
                                            .icon(BitmapDescriptorFactory.fromResource(R.drawable.school_marker))
                                            .title(name));
                                }
                                if (category.equals("all") || category.equals(MapFragment.this.category)) {
                                    map.addMarker(new MarkerOptions().position(new LatLng(latitude, longitude))
                                            .icon(BitmapDescriptorFactory.fromResource(R.drawable.office_marker))
                                            .title(name));
                                }
                                if (category.equals("all") || category.equals(MapFragment.this.category)) {
                                    map.addMarker(new MarkerOptions().position(new LatLng(latitude, longitude))
                                            .icon(BitmapDescriptorFactory.fromResource(R.drawable.worship_place_marker))
                                            .title(name));
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                            }
                        });
            }

            @Override
            public void onKeyExited(String key) {
                Util.log("onKeyExited() "+key);
            }

            @Override
            public void onKeyMoved(String key, GeoLocation location) {
                Util.log("onKeyMoved() "+key);
            }

            @Override
            public void onGeoQueryReady() {
                Util.log("onGeoQueryReady() ");
            }

            @Override
            public void onGeoQueryError(DatabaseError error) {
                Util.log("onGeoQueryError() "+error.getMessage());
            }
        });
    }
}

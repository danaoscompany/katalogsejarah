package com.prod.smartcity;

import android.content.pm.PackageManager;
import android.os.Build;

import androidx.appcompat.app.AppCompatActivity;

public class BaseActivity extends AppCompatActivity {

    public interface PermissionListener {

        void onPermissionGranted();
        void onPermissionDenied();
    }

    private PermissionListener listener = null;

    public void checkPermissions(String[] permissions, PermissionListener listener) {
        this.listener = listener;
        if (Build.VERSION.SDK_INT >= 23) {
            boolean granted = true;
            for (String permission:permissions) {
                if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
                    granted = false;
                    break;
                }
            }
            if (granted) {
                if (listener != null) {
                    listener.onPermissionGranted();
                }
            } else {
                requestPermissions(permissions, 1);
            }
        } else {
            if (listener != null) {
                listener.onPermissionGranted();
            }
        }
    }

    public interface Listener {

        void onResponse(String response);
    }

    public void get(final Listener listener, final String url) {
        Util.get(this, new Util.Listener() {

            @Override
            public void onResponse(String response) {
                if (listener != null) {
                    listener.onResponse(response);
                }
            }
        }, url);
    }

    public void post(final Listener listener, final String url, final String ...params) {
        Util.post(this, new Util.Listener() {

            @Override
            public void onResponse(String response) {
                if (listener != null) {
                    listener.onResponse(response);
                }
            }
        }, url, params);
    }
}

package com.prod.smartcity;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;

import com.firebase.geofire.GeoFire;
import com.firebase.geofire.GeoLocation;
import com.firebase.geofire.GeoQueryEventListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.core.view.GravityCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class HomeActivity extends BaseActivity {
    MapFragment allFragment, hotelFragment, bankFragment, atmFragment, restaurantFragment, gasStationFragment, hospitalFragment;
    MapFragment schoolFragment, officeFragment, worshipPlaceFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setItemIconTintList(null);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {
                drawer.closeDrawer((int) GravityCompat.START);
                int id = menuItem.getItemId();
                if (id == R.id.nav_all) {
                    selectFragment(allFragment, "all");
                } else if (id == R.id.nav_hotel) {
                    selectFragment(hotelFragment, "hotel");
                } else if (id == R.id.nav_bank) {
                    selectFragment(bankFragment, "bank");
                } else if (id == R.id.nav_atm) {
                    selectFragment(atmFragment, "atm");
                } else if (id == R.id.nav_restaurant) {
                    selectFragment(restaurantFragment, "restaurant");
                } else if (id == R.id.nav_gas_station) {
                    selectFragment(gasStationFragment, "gas_station");
                } else if (id == R.id.nav_hospital) {
                    selectFragment(hospitalFragment, "hospital");
                } else if (id == R.id.nav_school) {
                    selectFragment(schoolFragment, "school");
                } else if (id == R.id.nav_office) {
                    selectFragment(officeFragment, "office");
                } else if (id == R.id.nav_worship_place) {
                    selectFragment(worshipPlaceFragment, "worship_place");
                }
                return false;
            }
        });
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.open_drawer, R.string.close_drawer) {

            public void onDrawerClosed(View view) {
                super.onDrawerClosed(view);
            }

            public void onDrawerOpened(View view) {
                super.onDrawerOpened(view);
            }
        };
        drawer.setDrawerListener(toggle);
        toggle.syncState();
        allFragment = new MapFragment("all");
        hotelFragment = new MapFragment("hotel");
        bankFragment = new MapFragment("bank");
        atmFragment = new MapFragment("atm");
        restaurantFragment = new MapFragment("restaurant");
        gasStationFragment = new MapFragment("gas_station");
        hospitalFragment = new MapFragment("hospital");
        schoolFragment = new MapFragment("school");
        officeFragment = new MapFragment("office");
        worshipPlaceFragment = new MapFragment("worship_place");
        selectFragment(allFragment, "all");
    }

    public void selectFragment(Fragment fr, String category) {
        if (category.equals("all")) {
            setTitle(R.string.all_category);
        } else if (category.equals("hotel")) {
            setTitle(R.string.hotel);
        } else if (category.equals("bank")) {
            setTitle(R.string.bank);
        } else if (category.equals("atm")) {
            setTitle(R.string.atm);
        } else if (category.equals("restaurant")) {
            setTitle(R.string.restaurant);
        } else if (category.equals("gas_station")) {
            setTitle(R.string.gas_station);
        } else if (category.equals("hospital")) {
            setTitle(R.string.hospital);
        } else if (category.equals("school")) {
            setTitle(R.string.school);
        } else if (category.equals("office")) {
            setTitle(R.string.office);
        } else if (category.equals("worship_place")) {
            setTitle(R.string.worship_place);
        }
        getSupportFragmentManager().beginTransaction().replace(R.id.content_main, fr).commit();
    }
}

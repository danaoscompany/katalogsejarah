package com.prod.smartcity;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Base64;

import com.firebase.geofire.GeoFire;
import com.firebase.geofire.GeoLocation;
import com.firebase.geofire.GeoQueryEventListener;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;

import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import okhttp3.FormBody;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;

public class MainActivity extends BaseActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        checkPermissions(new String[]{
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION
        }, new PermissionListener() {

            @Override
            public void onPermissionGranted() {
                init();
            }

            @Override
            public void onPermissionDenied() {
                finish();
            }
        });
    }

    private class KeyValue {
        String key, value;

        public KeyValue(String key, String value) {
            this.key = key;
            this.value = value;
        }
    }

    public void init() {
        final ProgressDialog dialog = Util.createDialog(this, "Memuat...");
        dialog.show();
        Util.run(new Runnable() {

            @Override
            public void run() {
                try {
                    final long timestamp = System.currentTimeMillis()/1000;
                    final String nonce = UUID.randomUUID().toString();
                    String signature = Util.encodeHmacSHA256("POST&https%3A%2F%2Faccount.api.here.com%2Foauth2%2Ftoken&grant_type%3Dclient_credentials%26oauth_consumer_key%3D"+Constants.OAUTH_CONSUMER_KEY+"%26oauth_nonce%3D"+nonce+"%26oauth_signature_method%3DHMAC-SHA256%26oauth_timestamp%3D"+timestamp+"%26oauth_version%3D1.0",
                            Constants.OAUTH_SECRET+"&");
                    String signatureBase64 = Base64.encodeToString(signature.getBytes(), Base64.NO_WRAP);
                    OkHttpClient client = new OkHttpClient.Builder()
                            .readTimeout(60, TimeUnit.SECONDS)
                            .writeTimeout(60, TimeUnit.SECONDS)
                            .connectTimeout(60, TimeUnit.SECONDS)
                            .build();
                    RequestBody data = new FormBody.Builder()
                            .addEncoded("grant_type", "client_credentials")
                            .build();
                    Request request = new Request.Builder()
                            .url("https://account.api.here.com/oauth2/token")
                            .addHeader("Authorization", "OAuth oauth_consumer_key=\""+Constants.OAUTH_CONSUMER_KEY+"\", oauth_nonce=\""+nonce+"\", oauth_signature=\""+URLEncoder.encode(signature)+"\", oauth_signature_method=\"HMAC-SHA256\", oauth_timestamp=\""+timestamp+"\", oauth_version=\"1.0\"")
                            .post(data)
                            .build();
                    final String response = client.newCall(request).execute().body().string();
                    Util.runLater(new Runnable() {

                        @Override
                        public void run() {
                            Util.log("RESPONSE = "+response);
                            try {
                                JSONObject obj = new JSONObject(response);
                                String accessToken = Util.getString(obj, "access_token", "").trim();
                                Constants.ACCESS_TOKEN = accessToken;
                                dialog.dismiss();
                                startActivity(new Intent(MainActivity.this, HomeActivity.class));
                                finish();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}

package com.prod.smartcity;

public class Constants {
    public static final String HERE_API_KEY = "MoQ0dUWNJV-bKC-CYHsacni-G80cCWiX31B4fRAuM-o";
    public static final String FIREBASE_DATABASE_URL = "https://smart-city-fbd41-default-rtdb.firebaseio.com";
    public static final String OAUTH_CONSUMER_KEY = "4nu0KabdQ3J1MSW2zflHbg";
    public static final String OAUTH_SECRET = "uIlfSFu8PKuE79ggOKGgA4h3USmPg98iUJOhuCCVB-OjjXvqP14q-gAb4-6MK3b6vwbN8b8XvzEtZlPIOtwqDA";
    public static String ACCESS_TOKEN = "";
}

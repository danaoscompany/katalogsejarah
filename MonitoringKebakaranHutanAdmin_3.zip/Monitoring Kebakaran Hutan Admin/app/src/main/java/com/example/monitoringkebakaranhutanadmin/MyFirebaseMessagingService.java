package com.example.monitoringkebakaranhutanadmin;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class MyFirebaseMessagingService extends FirebaseMessagingService {

    @Override
    public void onMessageReceived(@NonNull RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);
        try {
            NotificationManager mgr = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            NotificationCompat.Builder builder = new NotificationCompat.Builder(this, getPackageName()+".NOTIFICATIONS");
            builder.setContentTitle(getResources().getString(R.string.text13));
            builder.setContentText(getResources().getString(R.string.text14));
            builder.setSmallIcon(R.mipmap.ic_launcher);
            builder.setContentIntent(PendingIntent.getActivity(this, 0, new Intent(this, HomeActivity.class),
                    PendingIntent.FLAG_UPDATE_CURRENT));
            builder.setPriority(NotificationCompat.PRIORITY_DEFAULT);
            mgr.notify(1, builder.build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

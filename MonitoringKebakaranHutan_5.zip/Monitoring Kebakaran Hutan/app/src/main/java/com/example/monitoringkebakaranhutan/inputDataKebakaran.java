package com.example.monitoringkebakaranhutan;

public class inputDataKebakaran {

    private String Date;
    private String Jam;
    private String Notelp;
    private String penyebabKebakaran;
    private String lokasiKebakaran;

    public inputDataKebakaran () {

    }
    public String getDate() {
        return Date;
    }
    public void setDate(String date) {
        Date = date;
    }

    public String getJam() {
        return Jam;
    }

    public void setJam(String jam) {
        Jam = jam;
    }

    public String getNotelp() {
        return Notelp;
    }

    public void setNotelp(String notelp) {
        Notelp = notelp;
    }

    public String getPenyebabKebakaran() {
        return penyebabKebakaran;
    }

    public void setPenyebabKebakaran(String penyebabKebakaran) {
        this.penyebabKebakaran = penyebabKebakaran;
    }

    public String getLokasiKebakaran() {
        return lokasiKebakaran;
    }

    public void setLokasiKebakaran(String lokasiKebakaran) {
        this.lokasiKebakaran = lokasiKebakaran;
    }

    public inputDataKebakaran (String Date, String jam, String Notelp, String penyebabKebakaran, String lokasiKebakaran){
        this.Date = Date;
        this.Jam = jam;
        this.Notelp = Notelp;
        this.penyebabKebakaran = penyebabKebakaran;
        this.lokasiKebakaran = lokasiKebakaran;
    }

}



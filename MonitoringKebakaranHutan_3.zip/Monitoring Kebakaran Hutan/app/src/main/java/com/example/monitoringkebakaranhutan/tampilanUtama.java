package com.example.monitoringkebakaranhutan;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.iid.FirebaseInstanceId;

public class tampilanUtama extends AppCompatActivity {
    private Button logout;
    private ImageView profileUser, titikapi, inputDataApi, info;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_tampilan_utama );

        profileUser = (ImageView) findViewById( R.id.profileUser );
        profileUser.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity( new Intent( tampilanUtama.this, profileUser.class ) );
            }
        });

        logout = (Button) findViewById( R.id.logout );
        logout.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Tool.write(tampilanUtama.this, "email", "");
                Tool.write(tampilanUtama.this, "password", "");
                FirebaseAuth.getInstance().signOut();
                startActivity( new Intent( tampilanUtama.this, MainActivity.class ) );
                finish();
            }
        });

        titikapi = (ImageView) findViewById( R.id.titikapi );
        titikapi.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity( new Intent( tampilanUtama.this, MapsActivity.class ) );
            }
        });

        inputDataApi = (ImageView) findViewById( R.id.inputTitikApi );
        inputDataApi.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity( new Intent( tampilanUtama.this, com.example.monitoringkebakaranhutan.inputDataApi.class ));
            }
        });

        info = (ImageView) findViewById( R.id.info );
        info.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                startActivity(new Intent(tampilanUtama.this, InfoActivity.class));
            }
        });

        final ProgressDialog dialog = Tool.createDialog(this, "Memuat...");
        dialog.show();
        String fcmID = FirebaseInstanceId.getInstance().getToken();
        FirebaseDatabase.getInstance().getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                .child("fcm_id").setValue(fcmID).addOnSuccessListener(new OnSuccessListener<Void>() {

            @Override
            public void onSuccess(Void aVoid) {
                dialog.dismiss();
            }
        });
    }
}
